./makebomb.pl -i 201580077 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201580077
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201580077
cd ../..
cp ./bombs/bomb201580077/bomb ./allbombs/CS201402/U201580077
cp ./bombs/bomb201580077/bomb.c ./allbombs/CS201402/U201580077
cp ./bombs/bomb201580077/ID ./allbombs/CS201402/U201580077
cp ./bombs/bomb201580077/README ./allbombs/CS201402/U201580077
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201314826 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201314826
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201314826
cd ../..
cp ./bombs/bomb201314826/bomb ./allbombs/CS201402/U201314826
cp ./bombs/bomb201314826/bomb.c ./allbombs/CS201402/U201314826
cp ./bombs/bomb201314826/ID ./allbombs/CS201402/U201314826
cp ./bombs/bomb201314826/README ./allbombs/CS201402/U201314826
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414572 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414572
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414572
cd ../..
cp ./bombs/bomb201414572/bomb ./allbombs/CS201402/U201414572
cp ./bombs/bomb201414572/bomb.c ./allbombs/CS201402/U201414572
cp ./bombs/bomb201414572/ID ./allbombs/CS201402/U201414572
cp ./bombs/bomb201414572/README ./allbombs/CS201402/U201414572
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414587 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414587
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414587
cd ../..
cp ./bombs/bomb201414587/bomb ./allbombs/CS201402/U201414587
cp ./bombs/bomb201414587/bomb.c ./allbombs/CS201402/U201414587
cp ./bombs/bomb201414587/ID ./allbombs/CS201402/U201414587
cp ./bombs/bomb201414587/README ./allbombs/CS201402/U201414587
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414589 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414589
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414589
cd ../..
cp ./bombs/bomb201414589/bomb ./allbombs/CS201402/U201414589
cp ./bombs/bomb201414589/bomb.c ./allbombs/CS201402/U201414589
cp ./bombs/bomb201414589/ID ./allbombs/CS201402/U201414589
cp ./bombs/bomb201414589/README ./allbombs/CS201402/U201414589
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414590 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414590
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414590
cd ../..
cp ./bombs/bomb201414590/bomb ./allbombs/CS201402/U201414590
cp ./bombs/bomb201414590/bomb.c ./allbombs/CS201402/U201414590
cp ./bombs/bomb201414590/ID ./allbombs/CS201402/U201414590
cp ./bombs/bomb201414590/README ./allbombs/CS201402/U201414590
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414591 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414591
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414591
cd ../..
cp ./bombs/bomb201414591/bomb ./allbombs/CS201402/U201414591
cp ./bombs/bomb201414591/bomb.c ./allbombs/CS201402/U201414591
cp ./bombs/bomb201414591/ID ./allbombs/CS201402/U201414591
cp ./bombs/bomb201414591/README ./allbombs/CS201402/U201414591
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414593 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414593
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414593
cd ../..
cp ./bombs/bomb201414593/bomb ./allbombs/CS201402/U201414593
cp ./bombs/bomb201414593/bomb.c ./allbombs/CS201402/U201414593
cp ./bombs/bomb201414593/ID ./allbombs/CS201402/U201414593
cp ./bombs/bomb201414593/README ./allbombs/CS201402/U201414593
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414594 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414594
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414594
cd ../..
cp ./bombs/bomb201414594/bomb ./allbombs/CS201402/U201414594
cp ./bombs/bomb201414594/bomb.c ./allbombs/CS201402/U201414594
cp ./bombs/bomb201414594/ID ./allbombs/CS201402/U201414594
cp ./bombs/bomb201414594/README ./allbombs/CS201402/U201414594
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414597 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414597
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414597
cd ../..
cp ./bombs/bomb201414597/bomb ./allbombs/CS201402/U201414597
cp ./bombs/bomb201414597/bomb.c ./allbombs/CS201402/U201414597
cp ./bombs/bomb201414597/ID ./allbombs/CS201402/U201414597
cp ./bombs/bomb201414597/README ./allbombs/CS201402/U201414597
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414598 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414598
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414598
cd ../..
cp ./bombs/bomb201414598/bomb ./allbombs/CS201402/U201414598
cp ./bombs/bomb201414598/bomb.c ./allbombs/CS201402/U201414598
cp ./bombs/bomb201414598/ID ./allbombs/CS201402/U201414598
cp ./bombs/bomb201414598/README ./allbombs/CS201402/U201414598
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414599 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414599
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414599
cd ../..
cp ./bombs/bomb201414599/bomb ./allbombs/CS201402/U201414599
cp ./bombs/bomb201414599/bomb.c ./allbombs/CS201402/U201414599
cp ./bombs/bomb201414599/ID ./allbombs/CS201402/U201414599
cp ./bombs/bomb201414599/README ./allbombs/CS201402/U201414599
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414600 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414600
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414600
cd ../..
cp ./bombs/bomb201414600/bomb ./allbombs/CS201402/U201414600
cp ./bombs/bomb201414600/bomb.c ./allbombs/CS201402/U201414600
cp ./bombs/bomb201414600/ID ./allbombs/CS201402/U201414600
cp ./bombs/bomb201414600/README ./allbombs/CS201402/U201414600
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414601 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414601
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414601
cd ../..
cp ./bombs/bomb201414601/bomb ./allbombs/CS201402/U201414601
cp ./bombs/bomb201414601/bomb.c ./allbombs/CS201402/U201414601
cp ./bombs/bomb201414601/ID ./allbombs/CS201402/U201414601
cp ./bombs/bomb201414601/README ./allbombs/CS201402/U201414601
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414602 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414602
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414602
cd ../..
cp ./bombs/bomb201414602/bomb ./allbombs/CS201402/U201414602
cp ./bombs/bomb201414602/bomb.c ./allbombs/CS201402/U201414602
cp ./bombs/bomb201414602/ID ./allbombs/CS201402/U201414602
cp ./bombs/bomb201414602/README ./allbombs/CS201402/U201414602
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414603 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414603
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414603
cd ../..
cp ./bombs/bomb201414603/bomb ./allbombs/CS201402/U201414603
cp ./bombs/bomb201414603/bomb.c ./allbombs/CS201402/U201414603
cp ./bombs/bomb201414603/ID ./allbombs/CS201402/U201414603
cp ./bombs/bomb201414603/README ./allbombs/CS201402/U201414603
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414604 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414604
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414604
cd ../..
cp ./bombs/bomb201414604/bomb ./allbombs/CS201402/U201414604
cp ./bombs/bomb201414604/bomb.c ./allbombs/CS201402/U201414604
cp ./bombs/bomb201414604/ID ./allbombs/CS201402/U201414604
cp ./bombs/bomb201414604/README ./allbombs/CS201402/U201414604
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414605 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414605
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414605
cd ../..
cp ./bombs/bomb201414605/bomb ./allbombs/CS201402/U201414605
cp ./bombs/bomb201414605/bomb.c ./allbombs/CS201402/U201414605
cp ./bombs/bomb201414605/ID ./allbombs/CS201402/U201414605
cp ./bombs/bomb201414605/README ./allbombs/CS201402/U201414605
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414606 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414606
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414606
cd ../..
cp ./bombs/bomb201414606/bomb ./allbombs/CS201402/U201414606
cp ./bombs/bomb201414606/bomb.c ./allbombs/CS201402/U201414606
cp ./bombs/bomb201414606/ID ./allbombs/CS201402/U201414606
cp ./bombs/bomb201414606/README ./allbombs/CS201402/U201414606
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414607 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414607
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414607
cd ../..
cp ./bombs/bomb201414607/bomb ./allbombs/CS201402/U201414607
cp ./bombs/bomb201414607/bomb.c ./allbombs/CS201402/U201414607
cp ./bombs/bomb201414607/ID ./allbombs/CS201402/U201414607
cp ./bombs/bomb201414607/README ./allbombs/CS201402/U201414607
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414608 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414608
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414608
cd ../..
cp ./bombs/bomb201414608/bomb ./allbombs/CS201402/U201414608
cp ./bombs/bomb201414608/bomb.c ./allbombs/CS201402/U201414608
cp ./bombs/bomb201414608/ID ./allbombs/CS201402/U201414608
cp ./bombs/bomb201414608/README ./allbombs/CS201402/U201414608
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414609 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414609
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414609
cd ../..
cp ./bombs/bomb201414609/bomb ./allbombs/CS201402/U201414609
cp ./bombs/bomb201414609/bomb.c ./allbombs/CS201402/U201414609
cp ./bombs/bomb201414609/ID ./allbombs/CS201402/U201414609
cp ./bombs/bomb201414609/README ./allbombs/CS201402/U201414609
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414610 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414610
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414610
cd ../..
cp ./bombs/bomb201414610/bomb ./allbombs/CS201402/U201414610
cp ./bombs/bomb201414610/bomb.c ./allbombs/CS201402/U201414610
cp ./bombs/bomb201414610/ID ./allbombs/CS201402/U201414610
cp ./bombs/bomb201414610/README ./allbombs/CS201402/U201414610
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414611 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414611
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414611
cd ../..
cp ./bombs/bomb201414611/bomb ./allbombs/CS201402/U201414611
cp ./bombs/bomb201414611/bomb.c ./allbombs/CS201402/U201414611
cp ./bombs/bomb201414611/ID ./allbombs/CS201402/U201414611
cp ./bombs/bomb201414611/README ./allbombs/CS201402/U201414611
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414613 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414613
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414613
cd ../..
cp ./bombs/bomb201414613/bomb ./allbombs/CS201402/U201414613
cp ./bombs/bomb201414613/bomb.c ./allbombs/CS201402/U201414613
cp ./bombs/bomb201414613/ID ./allbombs/CS201402/U201414613
cp ./bombs/bomb201414613/README ./allbombs/CS201402/U201414613
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414614 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414614
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414614
cd ../..
cp ./bombs/bomb201414614/bomb ./allbombs/CS201402/U201414614
cp ./bombs/bomb201414614/bomb.c ./allbombs/CS201402/U201414614
cp ./bombs/bomb201414614/ID ./allbombs/CS201402/U201414614
cp ./bombs/bomb201414614/README ./allbombs/CS201402/U201414614
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414615 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414615
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414615
cd ../..
cp ./bombs/bomb201414615/bomb ./allbombs/CS201402/U201414615
cp ./bombs/bomb201414615/bomb.c ./allbombs/CS201402/U201414615
cp ./bombs/bomb201414615/ID ./allbombs/CS201402/U201414615
cp ./bombs/bomb201414615/README ./allbombs/CS201402/U201414615
cd allbombs
zip -r CS201402.zip CS201402
cd ..

./makebomb.pl -i 201414616 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414616
cd allbombs
mkdir CS201402
cd CS201402
mkdir U201414616
cd ../..
cp ./bombs/bomb201414616/bomb ./allbombs/CS201402/U201414616
cp ./bombs/bomb201414616/bomb.c ./allbombs/CS201402/U201414616
cp ./bombs/bomb201414616/ID ./allbombs/CS201402/U201414616
cp ./bombs/bomb201414616/README ./allbombs/CS201402/U201414616
cd allbombs
zip -r CS201402.zip CS201402
cd ..

