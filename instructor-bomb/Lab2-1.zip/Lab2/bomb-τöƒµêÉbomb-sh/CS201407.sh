./makebomb.pl -i 201314987 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201314987
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201314987
cd ../..
cp ./bombs/bomb201314987/bomb ./allbombs/CS201407/U201314987
cp ./bombs/bomb201314987/bomb.c ./allbombs/CS201407/U201314987
cp ./bombs/bomb201314987/ID ./allbombs/CS201407/U201314987
cp ./bombs/bomb201314987/README ./allbombs/CS201407/U201314987
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414736 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414736
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414736
cd ../..
cp ./bombs/bomb201414736/bomb ./allbombs/CS201407/U201414736
cp ./bombs/bomb201414736/bomb.c ./allbombs/CS201407/U201414736
cp ./bombs/bomb201414736/ID ./allbombs/CS201407/U201414736
cp ./bombs/bomb201414736/README ./allbombs/CS201407/U201414736
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414737 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414737
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414737
cd ../..
cp ./bombs/bomb201414737/bomb ./allbombs/CS201407/U201414737
cp ./bombs/bomb201414737/bomb.c ./allbombs/CS201407/U201414737
cp ./bombs/bomb201414737/ID ./allbombs/CS201407/U201414737
cp ./bombs/bomb201414737/README ./allbombs/CS201407/U201414737
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414738 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414738
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414738
cd ../..
cp ./bombs/bomb201414738/bomb ./allbombs/CS201407/U201414738
cp ./bombs/bomb201414738/bomb.c ./allbombs/CS201407/U201414738
cp ./bombs/bomb201414738/ID ./allbombs/CS201407/U201414738
cp ./bombs/bomb201414738/README ./allbombs/CS201407/U201414738
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414740 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414740
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414740
cd ../..
cp ./bombs/bomb201414740/bomb ./allbombs/CS201407/U201414740
cp ./bombs/bomb201414740/bomb.c ./allbombs/CS201407/U201414740
cp ./bombs/bomb201414740/ID ./allbombs/CS201407/U201414740
cp ./bombs/bomb201414740/README ./allbombs/CS201407/U201414740
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414741 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414741
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414741
cd ../..
cp ./bombs/bomb201414741/bomb ./allbombs/CS201407/U201414741
cp ./bombs/bomb201414741/bomb.c ./allbombs/CS201407/U201414741
cp ./bombs/bomb201414741/ID ./allbombs/CS201407/U201414741
cp ./bombs/bomb201414741/README ./allbombs/CS201407/U201414741
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414742 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414742
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414742
cd ../..
cp ./bombs/bomb201414742/bomb ./allbombs/CS201407/U201414742
cp ./bombs/bomb201414742/bomb.c ./allbombs/CS201407/U201414742
cp ./bombs/bomb201414742/ID ./allbombs/CS201407/U201414742
cp ./bombs/bomb201414742/README ./allbombs/CS201407/U201414742
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414743 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414743
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414743
cd ../..
cp ./bombs/bomb201414743/bomb ./allbombs/CS201407/U201414743
cp ./bombs/bomb201414743/bomb.c ./allbombs/CS201407/U201414743
cp ./bombs/bomb201414743/ID ./allbombs/CS201407/U201414743
cp ./bombs/bomb201414743/README ./allbombs/CS201407/U201414743
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414744 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414744
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414744
cd ../..
cp ./bombs/bomb201414744/bomb ./allbombs/CS201407/U201414744
cp ./bombs/bomb201414744/bomb.c ./allbombs/CS201407/U201414744
cp ./bombs/bomb201414744/ID ./allbombs/CS201407/U201414744
cp ./bombs/bomb201414744/README ./allbombs/CS201407/U201414744
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414745 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414745
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414745
cd ../..
cp ./bombs/bomb201414745/bomb ./allbombs/CS201407/U201414745
cp ./bombs/bomb201414745/bomb.c ./allbombs/CS201407/U201414745
cp ./bombs/bomb201414745/ID ./allbombs/CS201407/U201414745
cp ./bombs/bomb201414745/README ./allbombs/CS201407/U201414745
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414746 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414746
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414746
cd ../..
cp ./bombs/bomb201414746/bomb ./allbombs/CS201407/U201414746
cp ./bombs/bomb201414746/bomb.c ./allbombs/CS201407/U201414746
cp ./bombs/bomb201414746/ID ./allbombs/CS201407/U201414746
cp ./bombs/bomb201414746/README ./allbombs/CS201407/U201414746
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414747 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414747
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414747
cd ../..
cp ./bombs/bomb201414747/bomb ./allbombs/CS201407/U201414747
cp ./bombs/bomb201414747/bomb.c ./allbombs/CS201407/U201414747
cp ./bombs/bomb201414747/ID ./allbombs/CS201407/U201414747
cp ./bombs/bomb201414747/README ./allbombs/CS201407/U201414747
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414748 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414748
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414748
cd ../..
cp ./bombs/bomb201414748/bomb ./allbombs/CS201407/U201414748
cp ./bombs/bomb201414748/bomb.c ./allbombs/CS201407/U201414748
cp ./bombs/bomb201414748/ID ./allbombs/CS201407/U201414748
cp ./bombs/bomb201414748/README ./allbombs/CS201407/U201414748
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414749 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414749
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414749
cd ../..
cp ./bombs/bomb201414749/bomb ./allbombs/CS201407/U201414749
cp ./bombs/bomb201414749/bomb.c ./allbombs/CS201407/U201414749
cp ./bombs/bomb201414749/ID ./allbombs/CS201407/U201414749
cp ./bombs/bomb201414749/README ./allbombs/CS201407/U201414749
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414750 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414750
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414750
cd ../..
cp ./bombs/bomb201414750/bomb ./allbombs/CS201407/U201414750
cp ./bombs/bomb201414750/bomb.c ./allbombs/CS201407/U201414750
cp ./bombs/bomb201414750/ID ./allbombs/CS201407/U201414750
cp ./bombs/bomb201414750/README ./allbombs/CS201407/U201414750
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414751 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414751
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414751
cd ../..
cp ./bombs/bomb201414751/bomb ./allbombs/CS201407/U201414751
cp ./bombs/bomb201414751/bomb.c ./allbombs/CS201407/U201414751
cp ./bombs/bomb201414751/ID ./allbombs/CS201407/U201414751
cp ./bombs/bomb201414751/README ./allbombs/CS201407/U201414751
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414752 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414752
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414752
cd ../..
cp ./bombs/bomb201414752/bomb ./allbombs/CS201407/U201414752
cp ./bombs/bomb201414752/bomb.c ./allbombs/CS201407/U201414752
cp ./bombs/bomb201414752/ID ./allbombs/CS201407/U201414752
cp ./bombs/bomb201414752/README ./allbombs/CS201407/U201414752
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414753 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414753
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414753
cd ../..
cp ./bombs/bomb201414753/bomb ./allbombs/CS201407/U201414753
cp ./bombs/bomb201414753/bomb.c ./allbombs/CS201407/U201414753
cp ./bombs/bomb201414753/ID ./allbombs/CS201407/U201414753
cp ./bombs/bomb201414753/README ./allbombs/CS201407/U201414753
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414754 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414754
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414754
cd ../..
cp ./bombs/bomb201414754/bomb ./allbombs/CS201407/U201414754
cp ./bombs/bomb201414754/bomb.c ./allbombs/CS201407/U201414754
cp ./bombs/bomb201414754/ID ./allbombs/CS201407/U201414754
cp ./bombs/bomb201414754/README ./allbombs/CS201407/U201414754
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414756 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414756
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414756
cd ../..
cp ./bombs/bomb201414756/bomb ./allbombs/CS201407/U201414756
cp ./bombs/bomb201414756/bomb.c ./allbombs/CS201407/U201414756
cp ./bombs/bomb201414756/ID ./allbombs/CS201407/U201414756
cp ./bombs/bomb201414756/README ./allbombs/CS201407/U201414756
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414757 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414757
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414757
cd ../..
cp ./bombs/bomb201414757/bomb ./allbombs/CS201407/U201414757
cp ./bombs/bomb201414757/bomb.c ./allbombs/CS201407/U201414757
cp ./bombs/bomb201414757/ID ./allbombs/CS201407/U201414757
cp ./bombs/bomb201414757/README ./allbombs/CS201407/U201414757
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414758 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414758
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414758
cd ../..
cp ./bombs/bomb201414758/bomb ./allbombs/CS201407/U201414758
cp ./bombs/bomb201414758/bomb.c ./allbombs/CS201407/U201414758
cp ./bombs/bomb201414758/ID ./allbombs/CS201407/U201414758
cp ./bombs/bomb201414758/README ./allbombs/CS201407/U201414758
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414759 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414759
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414759
cd ../..
cp ./bombs/bomb201414759/bomb ./allbombs/CS201407/U201414759
cp ./bombs/bomb201414759/bomb.c ./allbombs/CS201407/U201414759
cp ./bombs/bomb201414759/ID ./allbombs/CS201407/U201414759
cp ./bombs/bomb201414759/README ./allbombs/CS201407/U201414759
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414760 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414760
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414760
cd ../..
cp ./bombs/bomb201414760/bomb ./allbombs/CS201407/U201414760
cp ./bombs/bomb201414760/bomb.c ./allbombs/CS201407/U201414760
cp ./bombs/bomb201414760/ID ./allbombs/CS201407/U201414760
cp ./bombs/bomb201414760/README ./allbombs/CS201407/U201414760
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414761 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414761
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414761
cd ../..
cp ./bombs/bomb201414761/bomb ./allbombs/CS201407/U201414761
cp ./bombs/bomb201414761/bomb.c ./allbombs/CS201407/U201414761
cp ./bombs/bomb201414761/ID ./allbombs/CS201407/U201414761
cp ./bombs/bomb201414761/README ./allbombs/CS201407/U201414761
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414762 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414762
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414762
cd ../..
cp ./bombs/bomb201414762/bomb ./allbombs/CS201407/U201414762
cp ./bombs/bomb201414762/bomb.c ./allbombs/CS201407/U201414762
cp ./bombs/bomb201414762/ID ./allbombs/CS201407/U201414762
cp ./bombs/bomb201414762/README ./allbombs/CS201407/U201414762
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414764 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414764
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414764
cd ../..
cp ./bombs/bomb201414764/bomb ./allbombs/CS201407/U201414764
cp ./bombs/bomb201414764/bomb.c ./allbombs/CS201407/U201414764
cp ./bombs/bomb201414764/ID ./allbombs/CS201407/U201414764
cp ./bombs/bomb201414764/README ./allbombs/CS201407/U201414764
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201414765 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414765
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201414765
cd ../..
cp ./bombs/bomb201414765/bomb ./allbombs/CS201407/U201414765
cp ./bombs/bomb201414765/bomb.c ./allbombs/CS201407/U201414765
cp ./bombs/bomb201414765/ID ./allbombs/CS201407/U201414765
cp ./bombs/bomb201414765/README ./allbombs/CS201407/U201414765
cd allbombs
zip -r CS201407.zip CS201407
cd ..

./makebomb.pl -i 201417775 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201417775
cd allbombs
mkdir CS201407
cd CS201407
mkdir U201417775
cd ../..
cp ./bombs/bomb201417775/bomb ./allbombs/CS201407/U201417775
cp ./bombs/bomb201417775/bomb.c ./allbombs/CS201407/U201417775
cp ./bombs/bomb201417775/ID ./allbombs/CS201407/U201417775
cp ./bombs/bomb201417775/README ./allbombs/CS201407/U201417775
cd allbombs
zip -r CS201407.zip CS201407
cd ..

