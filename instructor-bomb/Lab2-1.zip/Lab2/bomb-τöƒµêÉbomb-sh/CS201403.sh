./makebomb.pl -i 201414617 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414617
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414617
cd ../..
cp ./bombs/bomb201414617/bomb ./allbombs/CS201403/U201414617
cp ./bombs/bomb201414617/bomb.c ./allbombs/CS201403/U201414617
cp ./bombs/bomb201414617/ID ./allbombs/CS201403/U201414617
cp ./bombs/bomb201414617/README ./allbombs/CS201403/U201414617
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414618 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414618
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414618
cd ../..
cp ./bombs/bomb201414618/bomb ./allbombs/CS201403/U201414618
cp ./bombs/bomb201414618/bomb.c ./allbombs/CS201403/U201414618
cp ./bombs/bomb201414618/ID ./allbombs/CS201403/U201414618
cp ./bombs/bomb201414618/README ./allbombs/CS201403/U201414618
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414619 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414619
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414619
cd ../..
cp ./bombs/bomb201414619/bomb ./allbombs/CS201403/U201414619
cp ./bombs/bomb201414619/bomb.c ./allbombs/CS201403/U201414619
cp ./bombs/bomb201414619/ID ./allbombs/CS201403/U201414619
cp ./bombs/bomb201414619/README ./allbombs/CS201403/U201414619
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414620 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414620
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414620
cd ../..
cp ./bombs/bomb201414620/bomb ./allbombs/CS201403/U201414620
cp ./bombs/bomb201414620/bomb.c ./allbombs/CS201403/U201414620
cp ./bombs/bomb201414620/ID ./allbombs/CS201403/U201414620
cp ./bombs/bomb201414620/README ./allbombs/CS201403/U201414620
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414621 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414621
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414621
cd ../..
cp ./bombs/bomb201414621/bomb ./allbombs/CS201403/U201414621
cp ./bombs/bomb201414621/bomb.c ./allbombs/CS201403/U201414621
cp ./bombs/bomb201414621/ID ./allbombs/CS201403/U201414621
cp ./bombs/bomb201414621/README ./allbombs/CS201403/U201414621
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414622 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414622
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414622
cd ../..
cp ./bombs/bomb201414622/bomb ./allbombs/CS201403/U201414622
cp ./bombs/bomb201414622/bomb.c ./allbombs/CS201403/U201414622
cp ./bombs/bomb201414622/ID ./allbombs/CS201403/U201414622
cp ./bombs/bomb201414622/README ./allbombs/CS201403/U201414622
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414623 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414623
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414623
cd ../..
cp ./bombs/bomb201414623/bomb ./allbombs/CS201403/U201414623
cp ./bombs/bomb201414623/bomb.c ./allbombs/CS201403/U201414623
cp ./bombs/bomb201414623/ID ./allbombs/CS201403/U201414623
cp ./bombs/bomb201414623/README ./allbombs/CS201403/U201414623
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414624 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414624
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414624
cd ../..
cp ./bombs/bomb201414624/bomb ./allbombs/CS201403/U201414624
cp ./bombs/bomb201414624/bomb.c ./allbombs/CS201403/U201414624
cp ./bombs/bomb201414624/ID ./allbombs/CS201403/U201414624
cp ./bombs/bomb201414624/README ./allbombs/CS201403/U201414624
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414625 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414625
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414625
cd ../..
cp ./bombs/bomb201414625/bomb ./allbombs/CS201403/U201414625
cp ./bombs/bomb201414625/bomb.c ./allbombs/CS201403/U201414625
cp ./bombs/bomb201414625/ID ./allbombs/CS201403/U201414625
cp ./bombs/bomb201414625/README ./allbombs/CS201403/U201414625
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414626 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414626
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414626
cd ../..
cp ./bombs/bomb201414626/bomb ./allbombs/CS201403/U201414626
cp ./bombs/bomb201414626/bomb.c ./allbombs/CS201403/U201414626
cp ./bombs/bomb201414626/ID ./allbombs/CS201403/U201414626
cp ./bombs/bomb201414626/README ./allbombs/CS201403/U201414626
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414627 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414627
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414627
cd ../..
cp ./bombs/bomb201414627/bomb ./allbombs/CS201403/U201414627
cp ./bombs/bomb201414627/bomb.c ./allbombs/CS201403/U201414627
cp ./bombs/bomb201414627/ID ./allbombs/CS201403/U201414627
cp ./bombs/bomb201414627/README ./allbombs/CS201403/U201414627
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414628 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414628
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414628
cd ../..
cp ./bombs/bomb201414628/bomb ./allbombs/CS201403/U201414628
cp ./bombs/bomb201414628/bomb.c ./allbombs/CS201403/U201414628
cp ./bombs/bomb201414628/ID ./allbombs/CS201403/U201414628
cp ./bombs/bomb201414628/README ./allbombs/CS201403/U201414628
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414630 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414630
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414630
cd ../..
cp ./bombs/bomb201414630/bomb ./allbombs/CS201403/U201414630
cp ./bombs/bomb201414630/bomb.c ./allbombs/CS201403/U201414630
cp ./bombs/bomb201414630/ID ./allbombs/CS201403/U201414630
cp ./bombs/bomb201414630/README ./allbombs/CS201403/U201414630
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414631 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414631
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414631
cd ../..
cp ./bombs/bomb201414631/bomb ./allbombs/CS201403/U201414631
cp ./bombs/bomb201414631/bomb.c ./allbombs/CS201403/U201414631
cp ./bombs/bomb201414631/ID ./allbombs/CS201403/U201414631
cp ./bombs/bomb201414631/README ./allbombs/CS201403/U201414631
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414632 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414632
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414632
cd ../..
cp ./bombs/bomb201414632/bomb ./allbombs/CS201403/U201414632
cp ./bombs/bomb201414632/bomb.c ./allbombs/CS201403/U201414632
cp ./bombs/bomb201414632/ID ./allbombs/CS201403/U201414632
cp ./bombs/bomb201414632/README ./allbombs/CS201403/U201414632
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414633 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414633
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414633
cd ../..
cp ./bombs/bomb201414633/bomb ./allbombs/CS201403/U201414633
cp ./bombs/bomb201414633/bomb.c ./allbombs/CS201403/U201414633
cp ./bombs/bomb201414633/ID ./allbombs/CS201403/U201414633
cp ./bombs/bomb201414633/README ./allbombs/CS201403/U201414633
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414634 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414634
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414634
cd ../..
cp ./bombs/bomb201414634/bomb ./allbombs/CS201403/U201414634
cp ./bombs/bomb201414634/bomb.c ./allbombs/CS201403/U201414634
cp ./bombs/bomb201414634/ID ./allbombs/CS201403/U201414634
cp ./bombs/bomb201414634/README ./allbombs/CS201403/U201414634
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414635 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414635
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414635
cd ../..
cp ./bombs/bomb201414635/bomb ./allbombs/CS201403/U201414635
cp ./bombs/bomb201414635/bomb.c ./allbombs/CS201403/U201414635
cp ./bombs/bomb201414635/ID ./allbombs/CS201403/U201414635
cp ./bombs/bomb201414635/README ./allbombs/CS201403/U201414635
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414636 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414636
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414636
cd ../..
cp ./bombs/bomb201414636/bomb ./allbombs/CS201403/U201414636
cp ./bombs/bomb201414636/bomb.c ./allbombs/CS201403/U201414636
cp ./bombs/bomb201414636/ID ./allbombs/CS201403/U201414636
cp ./bombs/bomb201414636/README ./allbombs/CS201403/U201414636
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414637 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414637
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414637
cd ../..
cp ./bombs/bomb201414637/bomb ./allbombs/CS201403/U201414637
cp ./bombs/bomb201414637/bomb.c ./allbombs/CS201403/U201414637
cp ./bombs/bomb201414637/ID ./allbombs/CS201403/U201414637
cp ./bombs/bomb201414637/README ./allbombs/CS201403/U201414637
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414638 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414638
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414638
cd ../..
cp ./bombs/bomb201414638/bomb ./allbombs/CS201403/U201414638
cp ./bombs/bomb201414638/bomb.c ./allbombs/CS201403/U201414638
cp ./bombs/bomb201414638/ID ./allbombs/CS201403/U201414638
cp ./bombs/bomb201414638/README ./allbombs/CS201403/U201414638
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414640 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414640
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414640
cd ../..
cp ./bombs/bomb201414640/bomb ./allbombs/CS201403/U201414640
cp ./bombs/bomb201414640/bomb.c ./allbombs/CS201403/U201414640
cp ./bombs/bomb201414640/ID ./allbombs/CS201403/U201414640
cp ./bombs/bomb201414640/README ./allbombs/CS201403/U201414640
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414641 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414641
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414641
cd ../..
cp ./bombs/bomb201414641/bomb ./allbombs/CS201403/U201414641
cp ./bombs/bomb201414641/bomb.c ./allbombs/CS201403/U201414641
cp ./bombs/bomb201414641/ID ./allbombs/CS201403/U201414641
cp ./bombs/bomb201414641/README ./allbombs/CS201403/U201414641
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414642 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414642
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414642
cd ../..
cp ./bombs/bomb201414642/bomb ./allbombs/CS201403/U201414642
cp ./bombs/bomb201414642/bomb.c ./allbombs/CS201403/U201414642
cp ./bombs/bomb201414642/ID ./allbombs/CS201403/U201414642
cp ./bombs/bomb201414642/README ./allbombs/CS201403/U201414642
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414644 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414644
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414644
cd ../..
cp ./bombs/bomb201414644/bomb ./allbombs/CS201403/U201414644
cp ./bombs/bomb201414644/bomb.c ./allbombs/CS201403/U201414644
cp ./bombs/bomb201414644/ID ./allbombs/CS201403/U201414644
cp ./bombs/bomb201414644/README ./allbombs/CS201403/U201414644
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414645 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414645
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414645
cd ../..
cp ./bombs/bomb201414645/bomb ./allbombs/CS201403/U201414645
cp ./bombs/bomb201414645/bomb.c ./allbombs/CS201403/U201414645
cp ./bombs/bomb201414645/ID ./allbombs/CS201403/U201414645
cp ./bombs/bomb201414645/README ./allbombs/CS201403/U201414645
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414646 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414646
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414646
cd ../..
cp ./bombs/bomb201414646/bomb ./allbombs/CS201403/U201414646
cp ./bombs/bomb201414646/bomb.c ./allbombs/CS201403/U201414646
cp ./bombs/bomb201414646/ID ./allbombs/CS201403/U201414646
cp ./bombs/bomb201414646/README ./allbombs/CS201403/U201414646
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201414647 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414647
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201414647
cd ../..
cp ./bombs/bomb201414647/bomb ./allbombs/CS201403/U201414647
cp ./bombs/bomb201414647/bomb.c ./allbombs/CS201403/U201414647
cp ./bombs/bomb201414647/ID ./allbombs/CS201403/U201414647
cp ./bombs/bomb201414647/README ./allbombs/CS201403/U201414647
cd allbombs
zip -r CS201403.zip CS201403
cd ..

./makebomb.pl -i 201315112 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201315112
cd allbombs
mkdir CS201403
cd CS201403
mkdir U201315112
cd ../..
cp ./bombs/bomb201315112/bomb ./allbombs/CS201403/U201315112
cp ./bombs/bomb201315112/bomb.c ./allbombs/CS201403/U201315112
cp ./bombs/bomb201315112/ID ./allbombs/CS201403/U201315112
cp ./bombs/bomb201315112/README ./allbombs/CS201403/U201315112
cd allbombs
zip -r CS201403.zip CS201403
cd ..

