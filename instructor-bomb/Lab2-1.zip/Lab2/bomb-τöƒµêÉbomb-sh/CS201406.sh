./makebomb.pl -i 201414707 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414707
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414707
cd ../..
cp ./bombs/bomb201414707/bomb ./allbombs/CS201406/U201414707
cp ./bombs/bomb201414707/bomb.c ./allbombs/CS201406/U201414707
cp ./bombs/bomb201414707/ID ./allbombs/CS201406/U201414707
cp ./bombs/bomb201414707/README ./allbombs/CS201406/U201414707
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414708 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414708
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414708
cd ../..
cp ./bombs/bomb201414708/bomb ./allbombs/CS201406/U201414708
cp ./bombs/bomb201414708/bomb.c ./allbombs/CS201406/U201414708
cp ./bombs/bomb201414708/ID ./allbombs/CS201406/U201414708
cp ./bombs/bomb201414708/README ./allbombs/CS201406/U201414708
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414709 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414709
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414709
cd ../..
cp ./bombs/bomb201414709/bomb ./allbombs/CS201406/U201414709
cp ./bombs/bomb201414709/bomb.c ./allbombs/CS201406/U201414709
cp ./bombs/bomb201414709/ID ./allbombs/CS201406/U201414709
cp ./bombs/bomb201414709/README ./allbombs/CS201406/U201414709
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414711 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414711
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414711
cd ../..
cp ./bombs/bomb201414711/bomb ./allbombs/CS201406/U201414711
cp ./bombs/bomb201414711/bomb.c ./allbombs/CS201406/U201414711
cp ./bombs/bomb201414711/ID ./allbombs/CS201406/U201414711
cp ./bombs/bomb201414711/README ./allbombs/CS201406/U201414711
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414712 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414712
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414712
cd ../..
cp ./bombs/bomb201414712/bomb ./allbombs/CS201406/U201414712
cp ./bombs/bomb201414712/bomb.c ./allbombs/CS201406/U201414712
cp ./bombs/bomb201414712/ID ./allbombs/CS201406/U201414712
cp ./bombs/bomb201414712/README ./allbombs/CS201406/U201414712
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414713 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414713
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414713
cd ../..
cp ./bombs/bomb201414713/bomb ./allbombs/CS201406/U201414713
cp ./bombs/bomb201414713/bomb.c ./allbombs/CS201406/U201414713
cp ./bombs/bomb201414713/ID ./allbombs/CS201406/U201414713
cp ./bombs/bomb201414713/README ./allbombs/CS201406/U201414713
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414714 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414714
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414714
cd ../..
cp ./bombs/bomb201414714/bomb ./allbombs/CS201406/U201414714
cp ./bombs/bomb201414714/bomb.c ./allbombs/CS201406/U201414714
cp ./bombs/bomb201414714/ID ./allbombs/CS201406/U201414714
cp ./bombs/bomb201414714/README ./allbombs/CS201406/U201414714
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414715 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414715
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414715
cd ../..
cp ./bombs/bomb201414715/bomb ./allbombs/CS201406/U201414715
cp ./bombs/bomb201414715/bomb.c ./allbombs/CS201406/U201414715
cp ./bombs/bomb201414715/ID ./allbombs/CS201406/U201414715
cp ./bombs/bomb201414715/README ./allbombs/CS201406/U201414715
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414717 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414717
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414717
cd ../..
cp ./bombs/bomb201414717/bomb ./allbombs/CS201406/U201414717
cp ./bombs/bomb201414717/bomb.c ./allbombs/CS201406/U201414717
cp ./bombs/bomb201414717/ID ./allbombs/CS201406/U201414717
cp ./bombs/bomb201414717/README ./allbombs/CS201406/U201414717
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414718 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414718
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414718
cd ../..
cp ./bombs/bomb201414718/bomb ./allbombs/CS201406/U201414718
cp ./bombs/bomb201414718/bomb.c ./allbombs/CS201406/U201414718
cp ./bombs/bomb201414718/ID ./allbombs/CS201406/U201414718
cp ./bombs/bomb201414718/README ./allbombs/CS201406/U201414718
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414719 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414719
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414719
cd ../..
cp ./bombs/bomb201414719/bomb ./allbombs/CS201406/U201414719
cp ./bombs/bomb201414719/bomb.c ./allbombs/CS201406/U201414719
cp ./bombs/bomb201414719/ID ./allbombs/CS201406/U201414719
cp ./bombs/bomb201414719/README ./allbombs/CS201406/U201414719
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414720 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414720
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414720
cd ../..
cp ./bombs/bomb201414720/bomb ./allbombs/CS201406/U201414720
cp ./bombs/bomb201414720/bomb.c ./allbombs/CS201406/U201414720
cp ./bombs/bomb201414720/ID ./allbombs/CS201406/U201414720
cp ./bombs/bomb201414720/README ./allbombs/CS201406/U201414720
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414721 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414721
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414721
cd ../..
cp ./bombs/bomb201414721/bomb ./allbombs/CS201406/U201414721
cp ./bombs/bomb201414721/bomb.c ./allbombs/CS201406/U201414721
cp ./bombs/bomb201414721/ID ./allbombs/CS201406/U201414721
cp ./bombs/bomb201414721/README ./allbombs/CS201406/U201414721
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414722 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414722
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414722
cd ../..
cp ./bombs/bomb201414722/bomb ./allbombs/CS201406/U201414722
cp ./bombs/bomb201414722/bomb.c ./allbombs/CS201406/U201414722
cp ./bombs/bomb201414722/ID ./allbombs/CS201406/U201414722
cp ./bombs/bomb201414722/README ./allbombs/CS201406/U201414722
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414723 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414723
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414723
cd ../..
cp ./bombs/bomb201414723/bomb ./allbombs/CS201406/U201414723
cp ./bombs/bomb201414723/bomb.c ./allbombs/CS201406/U201414723
cp ./bombs/bomb201414723/ID ./allbombs/CS201406/U201414723
cp ./bombs/bomb201414723/README ./allbombs/CS201406/U201414723
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414725 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414725
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414725
cd ../..
cp ./bombs/bomb201414725/bomb ./allbombs/CS201406/U201414725
cp ./bombs/bomb201414725/bomb.c ./allbombs/CS201406/U201414725
cp ./bombs/bomb201414725/ID ./allbombs/CS201406/U201414725
cp ./bombs/bomb201414725/README ./allbombs/CS201406/U201414725
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414726 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414726
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414726
cd ../..
cp ./bombs/bomb201414726/bomb ./allbombs/CS201406/U201414726
cp ./bombs/bomb201414726/bomb.c ./allbombs/CS201406/U201414726
cp ./bombs/bomb201414726/ID ./allbombs/CS201406/U201414726
cp ./bombs/bomb201414726/README ./allbombs/CS201406/U201414726
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414727 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414727
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414727
cd ../..
cp ./bombs/bomb201414727/bomb ./allbombs/CS201406/U201414727
cp ./bombs/bomb201414727/bomb.c ./allbombs/CS201406/U201414727
cp ./bombs/bomb201414727/ID ./allbombs/CS201406/U201414727
cp ./bombs/bomb201414727/README ./allbombs/CS201406/U201414727
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414728 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414728
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414728
cd ../..
cp ./bombs/bomb201414728/bomb ./allbombs/CS201406/U201414728
cp ./bombs/bomb201414728/bomb.c ./allbombs/CS201406/U201414728
cp ./bombs/bomb201414728/ID ./allbombs/CS201406/U201414728
cp ./bombs/bomb201414728/README ./allbombs/CS201406/U201414728
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414729 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414729
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414729
cd ../..
cp ./bombs/bomb201414729/bomb ./allbombs/CS201406/U201414729
cp ./bombs/bomb201414729/bomb.c ./allbombs/CS201406/U201414729
cp ./bombs/bomb201414729/ID ./allbombs/CS201406/U201414729
cp ./bombs/bomb201414729/README ./allbombs/CS201406/U201414729
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414730 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414730
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414730
cd ../..
cp ./bombs/bomb201414730/bomb ./allbombs/CS201406/U201414730
cp ./bombs/bomb201414730/bomb.c ./allbombs/CS201406/U201414730
cp ./bombs/bomb201414730/ID ./allbombs/CS201406/U201414730
cp ./bombs/bomb201414730/README ./allbombs/CS201406/U201414730
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414731 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414731
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414731
cd ../..
cp ./bombs/bomb201414731/bomb ./allbombs/CS201406/U201414731
cp ./bombs/bomb201414731/bomb.c ./allbombs/CS201406/U201414731
cp ./bombs/bomb201414731/ID ./allbombs/CS201406/U201414731
cp ./bombs/bomb201414731/README ./allbombs/CS201406/U201414731
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414732 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414732
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414732
cd ../..
cp ./bombs/bomb201414732/bomb ./allbombs/CS201406/U201414732
cp ./bombs/bomb201414732/bomb.c ./allbombs/CS201406/U201414732
cp ./bombs/bomb201414732/ID ./allbombs/CS201406/U201414732
cp ./bombs/bomb201414732/README ./allbombs/CS201406/U201414732
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414733 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414733
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414733
cd ../..
cp ./bombs/bomb201414733/bomb ./allbombs/CS201406/U201414733
cp ./bombs/bomb201414733/bomb.c ./allbombs/CS201406/U201414733
cp ./bombs/bomb201414733/ID ./allbombs/CS201406/U201414733
cp ./bombs/bomb201414733/README ./allbombs/CS201406/U201414733
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414734 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414734
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414734
cd ../..
cp ./bombs/bomb201414734/bomb ./allbombs/CS201406/U201414734
cp ./bombs/bomb201414734/bomb.c ./allbombs/CS201406/U201414734
cp ./bombs/bomb201414734/ID ./allbombs/CS201406/U201414734
cp ./bombs/bomb201414734/README ./allbombs/CS201406/U201414734
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414735 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414735
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414735
cd ../..
cp ./bombs/bomb201414735/bomb ./allbombs/CS201406/U201414735
cp ./bombs/bomb201414735/bomb.c ./allbombs/CS201406/U201414735
cp ./bombs/bomb201414735/ID ./allbombs/CS201406/U201414735
cp ./bombs/bomb201414735/README ./allbombs/CS201406/U201414735
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201417773 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201417773
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201417773
cd ../..
cp ./bombs/bomb201417773/bomb ./allbombs/CS201406/U201417773
cp ./bombs/bomb201417773/bomb.c ./allbombs/CS201406/U201417773
cp ./bombs/bomb201417773/ID ./allbombs/CS201406/U201417773
cp ./bombs/bomb201417773/README ./allbombs/CS201406/U201417773
cd allbombs
zip -r CS201406.zip CS201406
cd ..

./makebomb.pl -i 201414710 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414710
cd allbombs
mkdir CS201406
cd CS201406
mkdir U201414710
cd ../..
cp ./bombs/bomb201414710/bomb ./allbombs/CS201406/U201414710
cp ./bombs/bomb201414710/bomb.c ./allbombs/CS201406/U201414710
cp ./bombs/bomb201414710/ID ./allbombs/CS201406/U201414710
cp ./bombs/bomb201414710/README ./allbombs/CS201406/U201414710
cd allbombs
zip -r CS201406.zip CS201406
cd ..

