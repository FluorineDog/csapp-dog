./makebomb.pl -i 201414679 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414679
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414679
cd ../..
cp ./bombs/bomb201414679/bomb ./allbombs/CS201401/U201414679
cp ./bombs/bomb201414679/bomb.c ./allbombs/CS201401/U201414679
cp ./bombs/bomb201414679/ID ./allbombs/CS201401/U201414679
cp ./bombs/bomb201414679/README ./allbombs/CS201401/U201414679
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414680 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414680
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414680
cd ../..
cp ./bombs/bomb201414680/bomb ./allbombs/CS201401/U201414680
cp ./bombs/bomb201414680/bomb.c ./allbombs/CS201401/U201414680
cp ./bombs/bomb201414680/ID ./allbombs/CS201401/U201414680
cp ./bombs/bomb201414680/README ./allbombs/CS201401/U201414680
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414681 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414681
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414681
cd ../..
cp ./bombs/bomb201414681/bomb ./allbombs/CS201401/U201414681
cp ./bombs/bomb201414681/bomb.c ./allbombs/CS201401/U201414681
cp ./bombs/bomb201414681/ID ./allbombs/CS201401/U201414681
cp ./bombs/bomb201414681/README ./allbombs/CS201401/U201414681
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414682 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414682
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414682
cd ../..
cp ./bombs/bomb201414682/bomb ./allbombs/CS201401/U201414682
cp ./bombs/bomb201414682/bomb.c ./allbombs/CS201401/U201414682
cp ./bombs/bomb201414682/ID ./allbombs/CS201401/U201414682
cp ./bombs/bomb201414682/README ./allbombs/CS201401/U201414682
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414683 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414683
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414683
cd ../..
cp ./bombs/bomb201414683/bomb ./allbombs/CS201401/U201414683
cp ./bombs/bomb201414683/bomb.c ./allbombs/CS201401/U201414683
cp ./bombs/bomb201414683/ID ./allbombs/CS201401/U201414683
cp ./bombs/bomb201414683/README ./allbombs/CS201401/U201414683
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414684 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414684
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414684
cd ../..
cp ./bombs/bomb201414684/bomb ./allbombs/CS201401/U201414684
cp ./bombs/bomb201414684/bomb.c ./allbombs/CS201401/U201414684
cp ./bombs/bomb201414684/ID ./allbombs/CS201401/U201414684
cp ./bombs/bomb201414684/README ./allbombs/CS201401/U201414684
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414685 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414685
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414685
cd ../..
cp ./bombs/bomb201414685/bomb ./allbombs/CS201401/U201414685
cp ./bombs/bomb201414685/bomb.c ./allbombs/CS201401/U201414685
cp ./bombs/bomb201414685/ID ./allbombs/CS201401/U201414685
cp ./bombs/bomb201414685/README ./allbombs/CS201401/U201414685
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414688 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414688
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414688
cd ../..
cp ./bombs/bomb201414688/bomb ./allbombs/CS201401/U201414688
cp ./bombs/bomb201414688/bomb.c ./allbombs/CS201401/U201414688
cp ./bombs/bomb201414688/ID ./allbombs/CS201401/U201414688
cp ./bombs/bomb201414688/README ./allbombs/CS201401/U201414688
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414689 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414689
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414689
cd ../..
cp ./bombs/bomb201414689/bomb ./allbombs/CS201401/U201414689
cp ./bombs/bomb201414689/bomb.c ./allbombs/CS201401/U201414689
cp ./bombs/bomb201414689/ID ./allbombs/CS201401/U201414689
cp ./bombs/bomb201414689/README ./allbombs/CS201401/U201414689
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414690 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414690
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414690
cd ../..
cp ./bombs/bomb201414690/bomb ./allbombs/CS201401/U201414690
cp ./bombs/bomb201414690/bomb.c ./allbombs/CS201401/U201414690
cp ./bombs/bomb201414690/ID ./allbombs/CS201401/U201414690
cp ./bombs/bomb201414690/README ./allbombs/CS201401/U201414690
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414691 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414691
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414691
cd ../..
cp ./bombs/bomb201414691/bomb ./allbombs/CS201401/U201414691
cp ./bombs/bomb201414691/bomb.c ./allbombs/CS201401/U201414691
cp ./bombs/bomb201414691/ID ./allbombs/CS201401/U201414691
cp ./bombs/bomb201414691/README ./allbombs/CS201401/U201414691
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414692 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414692
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414692
cd ../..
cp ./bombs/bomb201414692/bomb ./allbombs/CS201401/U201414692
cp ./bombs/bomb201414692/bomb.c ./allbombs/CS201401/U201414692
cp ./bombs/bomb201414692/ID ./allbombs/CS201401/U201414692
cp ./bombs/bomb201414692/README ./allbombs/CS201401/U201414692
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414693 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414693
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414693
cd ../..
cp ./bombs/bomb201414693/bomb ./allbombs/CS201401/U201414693
cp ./bombs/bomb201414693/bomb.c ./allbombs/CS201401/U201414693
cp ./bombs/bomb201414693/ID ./allbombs/CS201401/U201414693
cp ./bombs/bomb201414693/README ./allbombs/CS201401/U201414693
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414694 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414694
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414694
cd ../..
cp ./bombs/bomb201414694/bomb ./allbombs/CS201401/U201414694
cp ./bombs/bomb201414694/bomb.c ./allbombs/CS201401/U201414694
cp ./bombs/bomb201414694/ID ./allbombs/CS201401/U201414694
cp ./bombs/bomb201414694/README ./allbombs/CS201401/U201414694
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414695 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414695
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414695
cd ../..
cp ./bombs/bomb201414695/bomb ./allbombs/CS201401/U201414695
cp ./bombs/bomb201414695/bomb.c ./allbombs/CS201401/U201414695
cp ./bombs/bomb201414695/ID ./allbombs/CS201401/U201414695
cp ./bombs/bomb201414695/README ./allbombs/CS201401/U201414695
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414697 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414697
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414697
cd ../..
cp ./bombs/bomb201414697/bomb ./allbombs/CS201401/U201414697
cp ./bombs/bomb201414697/bomb.c ./allbombs/CS201401/U201414697
cp ./bombs/bomb201414697/ID ./allbombs/CS201401/U201414697
cp ./bombs/bomb201414697/README ./allbombs/CS201401/U201414697
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414698 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414698
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414698
cd ../..
cp ./bombs/bomb201414698/bomb ./allbombs/CS201401/U201414698
cp ./bombs/bomb201414698/bomb.c ./allbombs/CS201401/U201414698
cp ./bombs/bomb201414698/ID ./allbombs/CS201401/U201414698
cp ./bombs/bomb201414698/README ./allbombs/CS201401/U201414698
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414699 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414699
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414699
cd ../..
cp ./bombs/bomb201414699/bomb ./allbombs/CS201401/U201414699
cp ./bombs/bomb201414699/bomb.c ./allbombs/CS201401/U201414699
cp ./bombs/bomb201414699/ID ./allbombs/CS201401/U201414699
cp ./bombs/bomb201414699/README ./allbombs/CS201401/U201414699
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414700 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414700
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414700
cd ../..
cp ./bombs/bomb201414700/bomb ./allbombs/CS201401/U201414700
cp ./bombs/bomb201414700/bomb.c ./allbombs/CS201401/U201414700
cp ./bombs/bomb201414700/ID ./allbombs/CS201401/U201414700
cp ./bombs/bomb201414700/README ./allbombs/CS201401/U201414700
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414701 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414701
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414701
cd ../..
cp ./bombs/bomb201414701/bomb ./allbombs/CS201401/U201414701
cp ./bombs/bomb201414701/bomb.c ./allbombs/CS201401/U201414701
cp ./bombs/bomb201414701/ID ./allbombs/CS201401/U201414701
cp ./bombs/bomb201414701/README ./allbombs/CS201401/U201414701
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414703 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414703
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414703
cd ../..
cp ./bombs/bomb201414703/bomb ./allbombs/CS201401/U201414703
cp ./bombs/bomb201414703/bomb.c ./allbombs/CS201401/U201414703
cp ./bombs/bomb201414703/ID ./allbombs/CS201401/U201414703
cp ./bombs/bomb201414703/README ./allbombs/CS201401/U201414703
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414704 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414704
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414704
cd ../..
cp ./bombs/bomb201414704/bomb ./allbombs/CS201401/U201414704
cp ./bombs/bomb201414704/bomb.c ./allbombs/CS201401/U201414704
cp ./bombs/bomb201414704/ID ./allbombs/CS201401/U201414704
cp ./bombs/bomb201414704/README ./allbombs/CS201401/U201414704
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414705 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414705
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414705
cd ../..
cp ./bombs/bomb201414705/bomb ./allbombs/CS201401/U201414705
cp ./bombs/bomb201414705/bomb.c ./allbombs/CS201401/U201414705
cp ./bombs/bomb201414705/ID ./allbombs/CS201401/U201414705
cp ./bombs/bomb201414705/README ./allbombs/CS201401/U201414705
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414706 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414706
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414706
cd ../..
cp ./bombs/bomb201414706/bomb ./allbombs/CS201401/U201414706
cp ./bombs/bomb201414706/bomb.c ./allbombs/CS201401/U201414706
cp ./bombs/bomb201414706/ID ./allbombs/CS201401/U201414706
cp ./bombs/bomb201414706/README ./allbombs/CS201401/U201414706
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201314987 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201314987
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201314987
cd ../..
cp ./bombs/bomb201314987/bomb ./allbombs/CS201401/U201314987
cp ./bombs/bomb201314987/bomb.c ./allbombs/CS201401/U201314987
cp ./bombs/bomb201314987/ID ./allbombs/CS201401/U201314987
cp ./bombs/bomb201314987/README ./allbombs/CS201401/U201314987
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414736 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414736
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414736
cd ../..
cp ./bombs/bomb201414736/bomb ./allbombs/CS201401/U201414736
cp ./bombs/bomb201414736/bomb.c ./allbombs/CS201401/U201414736
cp ./bombs/bomb201414736/ID ./allbombs/CS201401/U201414736
cp ./bombs/bomb201414736/README ./allbombs/CS201401/U201414736
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414737 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414737
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414737
cd ../..
cp ./bombs/bomb201414737/bomb ./allbombs/CS201401/U201414737
cp ./bombs/bomb201414737/bomb.c ./allbombs/CS201401/U201414737
cp ./bombs/bomb201414737/ID ./allbombs/CS201401/U201414737
cp ./bombs/bomb201414737/README ./allbombs/CS201401/U201414737
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414738 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414738
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414738
cd ../..
cp ./bombs/bomb201414738/bomb ./allbombs/CS201401/U201414738
cp ./bombs/bomb201414738/bomb.c ./allbombs/CS201401/U201414738
cp ./bombs/bomb201414738/ID ./allbombs/CS201401/U201414738
cp ./bombs/bomb201414738/README ./allbombs/CS201401/U201414738
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414740 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414740
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414740
cd ../..
cp ./bombs/bomb201414740/bomb ./allbombs/CS201401/U201414740
cp ./bombs/bomb201414740/bomb.c ./allbombs/CS201401/U201414740
cp ./bombs/bomb201414740/ID ./allbombs/CS201401/U201414740
cp ./bombs/bomb201414740/README ./allbombs/CS201401/U201414740
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414741 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414741
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414741
cd ../..
cp ./bombs/bomb201414741/bomb ./allbombs/CS201401/U201414741
cp ./bombs/bomb201414741/bomb.c ./allbombs/CS201401/U201414741
cp ./bombs/bomb201414741/ID ./allbombs/CS201401/U201414741
cp ./bombs/bomb201414741/README ./allbombs/CS201401/U201414741
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414742 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414742
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414742
cd ../..
cp ./bombs/bomb201414742/bomb ./allbombs/CS201401/U201414742
cp ./bombs/bomb201414742/bomb.c ./allbombs/CS201401/U201414742
cp ./bombs/bomb201414742/ID ./allbombs/CS201401/U201414742
cp ./bombs/bomb201414742/README ./allbombs/CS201401/U201414742
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414743 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414743
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414743
cd ../..
cp ./bombs/bomb201414743/bomb ./allbombs/CS201401/U201414743
cp ./bombs/bomb201414743/bomb.c ./allbombs/CS201401/U201414743
cp ./bombs/bomb201414743/ID ./allbombs/CS201401/U201414743
cp ./bombs/bomb201414743/README ./allbombs/CS201401/U201414743
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414744 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414744
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414744
cd ../..
cp ./bombs/bomb201414744/bomb ./allbombs/CS201401/U201414744
cp ./bombs/bomb201414744/bomb.c ./allbombs/CS201401/U201414744
cp ./bombs/bomb201414744/ID ./allbombs/CS201401/U201414744
cp ./bombs/bomb201414744/README ./allbombs/CS201401/U201414744
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414745 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414745
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414745
cd ../..
cp ./bombs/bomb201414745/bomb ./allbombs/CS201401/U201414745
cp ./bombs/bomb201414745/bomb.c ./allbombs/CS201401/U201414745
cp ./bombs/bomb201414745/ID ./allbombs/CS201401/U201414745
cp ./bombs/bomb201414745/README ./allbombs/CS201401/U201414745
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414746 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414746
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414746
cd ../..
cp ./bombs/bomb201414746/bomb ./allbombs/CS201401/U201414746
cp ./bombs/bomb201414746/bomb.c ./allbombs/CS201401/U201414746
cp ./bombs/bomb201414746/ID ./allbombs/CS201401/U201414746
cp ./bombs/bomb201414746/README ./allbombs/CS201401/U201414746
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414747 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414747
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414747
cd ../..
cp ./bombs/bomb201414747/bomb ./allbombs/CS201401/U201414747
cp ./bombs/bomb201414747/bomb.c ./allbombs/CS201401/U201414747
cp ./bombs/bomb201414747/ID ./allbombs/CS201401/U201414747
cp ./bombs/bomb201414747/README ./allbombs/CS201401/U201414747
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414748 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414748
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414748
cd ../..
cp ./bombs/bomb201414748/bomb ./allbombs/CS201401/U201414748
cp ./bombs/bomb201414748/bomb.c ./allbombs/CS201401/U201414748
cp ./bombs/bomb201414748/ID ./allbombs/CS201401/U201414748
cp ./bombs/bomb201414748/README ./allbombs/CS201401/U201414748
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414749 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414749
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414749
cd ../..
cp ./bombs/bomb201414749/bomb ./allbombs/CS201401/U201414749
cp ./bombs/bomb201414749/bomb.c ./allbombs/CS201401/U201414749
cp ./bombs/bomb201414749/ID ./allbombs/CS201401/U201414749
cp ./bombs/bomb201414749/README ./allbombs/CS201401/U201414749
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414750 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414750
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414750
cd ../..
cp ./bombs/bomb201414750/bomb ./allbombs/CS201401/U201414750
cp ./bombs/bomb201414750/bomb.c ./allbombs/CS201401/U201414750
cp ./bombs/bomb201414750/ID ./allbombs/CS201401/U201414750
cp ./bombs/bomb201414750/README ./allbombs/CS201401/U201414750
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414751 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414751
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414751
cd ../..
cp ./bombs/bomb201414751/bomb ./allbombs/CS201401/U201414751
cp ./bombs/bomb201414751/bomb.c ./allbombs/CS201401/U201414751
cp ./bombs/bomb201414751/ID ./allbombs/CS201401/U201414751
cp ./bombs/bomb201414751/README ./allbombs/CS201401/U201414751
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414752 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414752
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414752
cd ../..
cp ./bombs/bomb201414752/bomb ./allbombs/CS201401/U201414752
cp ./bombs/bomb201414752/bomb.c ./allbombs/CS201401/U201414752
cp ./bombs/bomb201414752/ID ./allbombs/CS201401/U201414752
cp ./bombs/bomb201414752/README ./allbombs/CS201401/U201414752
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414753 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414753
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414753
cd ../..
cp ./bombs/bomb201414753/bomb ./allbombs/CS201401/U201414753
cp ./bombs/bomb201414753/bomb.c ./allbombs/CS201401/U201414753
cp ./bombs/bomb201414753/ID ./allbombs/CS201401/U201414753
cp ./bombs/bomb201414753/README ./allbombs/CS201401/U201414753
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414754 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414754
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414754
cd ../..
cp ./bombs/bomb201414754/bomb ./allbombs/CS201401/U201414754
cp ./bombs/bomb201414754/bomb.c ./allbombs/CS201401/U201414754
cp ./bombs/bomb201414754/ID ./allbombs/CS201401/U201414754
cp ./bombs/bomb201414754/README ./allbombs/CS201401/U201414754
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414756 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414756
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414756
cd ../..
cp ./bombs/bomb201414756/bomb ./allbombs/CS201401/U201414756
cp ./bombs/bomb201414756/bomb.c ./allbombs/CS201401/U201414756
cp ./bombs/bomb201414756/ID ./allbombs/CS201401/U201414756
cp ./bombs/bomb201414756/README ./allbombs/CS201401/U201414756
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414757 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414757
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414757
cd ../..
cp ./bombs/bomb201414757/bomb ./allbombs/CS201401/U201414757
cp ./bombs/bomb201414757/bomb.c ./allbombs/CS201401/U201414757
cp ./bombs/bomb201414757/ID ./allbombs/CS201401/U201414757
cp ./bombs/bomb201414757/README ./allbombs/CS201401/U201414757
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414758 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414758
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414758
cd ../..
cp ./bombs/bomb201414758/bomb ./allbombs/CS201401/U201414758
cp ./bombs/bomb201414758/bomb.c ./allbombs/CS201401/U201414758
cp ./bombs/bomb201414758/ID ./allbombs/CS201401/U201414758
cp ./bombs/bomb201414758/README ./allbombs/CS201401/U201414758
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414759 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414759
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414759
cd ../..
cp ./bombs/bomb201414759/bomb ./allbombs/CS201401/U201414759
cp ./bombs/bomb201414759/bomb.c ./allbombs/CS201401/U201414759
cp ./bombs/bomb201414759/ID ./allbombs/CS201401/U201414759
cp ./bombs/bomb201414759/README ./allbombs/CS201401/U201414759
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414760 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414760
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414760
cd ../..
cp ./bombs/bomb201414760/bomb ./allbombs/CS201401/U201414760
cp ./bombs/bomb201414760/bomb.c ./allbombs/CS201401/U201414760
cp ./bombs/bomb201414760/ID ./allbombs/CS201401/U201414760
cp ./bombs/bomb201414760/README ./allbombs/CS201401/U201414760
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414761 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414761
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414761
cd ../..
cp ./bombs/bomb201414761/bomb ./allbombs/CS201401/U201414761
cp ./bombs/bomb201414761/bomb.c ./allbombs/CS201401/U201414761
cp ./bombs/bomb201414761/ID ./allbombs/CS201401/U201414761
cp ./bombs/bomb201414761/README ./allbombs/CS201401/U201414761
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414762 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414762
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414762
cd ../..
cp ./bombs/bomb201414762/bomb ./allbombs/CS201401/U201414762
cp ./bombs/bomb201414762/bomb.c ./allbombs/CS201401/U201414762
cp ./bombs/bomb201414762/ID ./allbombs/CS201401/U201414762
cp ./bombs/bomb201414762/README ./allbombs/CS201401/U201414762
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414764 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414764
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414764
cd ../..
cp ./bombs/bomb201414764/bomb ./allbombs/CS201401/U201414764
cp ./bombs/bomb201414764/bomb.c ./allbombs/CS201401/U201414764
cp ./bombs/bomb201414764/ID ./allbombs/CS201401/U201414764
cp ./bombs/bomb201414764/README ./allbombs/CS201401/U201414764
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414765 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414765
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414765
cd ../..
cp ./bombs/bomb201414765/bomb ./allbombs/CS201401/U201414765
cp ./bombs/bomb201414765/bomb.c ./allbombs/CS201401/U201414765
cp ./bombs/bomb201414765/ID ./allbombs/CS201401/U201414765
cp ./bombs/bomb201414765/README ./allbombs/CS201401/U201414765
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201417775 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201417775
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201417775
cd ../..
cp ./bombs/bomb201417775/bomb ./allbombs/CS201401/U201417775
cp ./bombs/bomb201417775/bomb.c ./allbombs/CS201401/U201417775
cp ./bombs/bomb201417775/ID ./allbombs/CS201401/U201417775
cp ./bombs/bomb201417775/README ./allbombs/CS201401/U201417775
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414766 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414766
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414766
cd ../..
cp ./bombs/bomb201414766/bomb ./allbombs/CS201401/U201414766
cp ./bombs/bomb201414766/bomb.c ./allbombs/CS201401/U201414766
cp ./bombs/bomb201414766/ID ./allbombs/CS201401/U201414766
cp ./bombs/bomb201414766/README ./allbombs/CS201401/U201414766
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414767 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414767
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414767
cd ../..
cp ./bombs/bomb201414767/bomb ./allbombs/CS201401/U201414767
cp ./bombs/bomb201414767/bomb.c ./allbombs/CS201401/U201414767
cp ./bombs/bomb201414767/ID ./allbombs/CS201401/U201414767
cp ./bombs/bomb201414767/README ./allbombs/CS201401/U201414767
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414768 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414768
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414768
cd ../..
cp ./bombs/bomb201414768/bomb ./allbombs/CS201401/U201414768
cp ./bombs/bomb201414768/bomb.c ./allbombs/CS201401/U201414768
cp ./bombs/bomb201414768/ID ./allbombs/CS201401/U201414768
cp ./bombs/bomb201414768/README ./allbombs/CS201401/U201414768
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414769 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414769
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414769
cd ../..
cp ./bombs/bomb201414769/bomb ./allbombs/CS201401/U201414769
cp ./bombs/bomb201414769/bomb.c ./allbombs/CS201401/U201414769
cp ./bombs/bomb201414769/ID ./allbombs/CS201401/U201414769
cp ./bombs/bomb201414769/README ./allbombs/CS201401/U201414769
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414770 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414770
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414770
cd ../..
cp ./bombs/bomb201414770/bomb ./allbombs/CS201401/U201414770
cp ./bombs/bomb201414770/bomb.c ./allbombs/CS201401/U201414770
cp ./bombs/bomb201414770/ID ./allbombs/CS201401/U201414770
cp ./bombs/bomb201414770/README ./allbombs/CS201401/U201414770
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414771 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414771
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414771
cd ../..
cp ./bombs/bomb201414771/bomb ./allbombs/CS201401/U201414771
cp ./bombs/bomb201414771/bomb.c ./allbombs/CS201401/U201414771
cp ./bombs/bomb201414771/ID ./allbombs/CS201401/U201414771
cp ./bombs/bomb201414771/README ./allbombs/CS201401/U201414771
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414772 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414772
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414772
cd ../..
cp ./bombs/bomb201414772/bomb ./allbombs/CS201401/U201414772
cp ./bombs/bomb201414772/bomb.c ./allbombs/CS201401/U201414772
cp ./bombs/bomb201414772/ID ./allbombs/CS201401/U201414772
cp ./bombs/bomb201414772/README ./allbombs/CS201401/U201414772
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414773 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414773
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414773
cd ../..
cp ./bombs/bomb201414773/bomb ./allbombs/CS201401/U201414773
cp ./bombs/bomb201414773/bomb.c ./allbombs/CS201401/U201414773
cp ./bombs/bomb201414773/ID ./allbombs/CS201401/U201414773
cp ./bombs/bomb201414773/README ./allbombs/CS201401/U201414773
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414774 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414774
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414774
cd ../..
cp ./bombs/bomb201414774/bomb ./allbombs/CS201401/U201414774
cp ./bombs/bomb201414774/bomb.c ./allbombs/CS201401/U201414774
cp ./bombs/bomb201414774/ID ./allbombs/CS201401/U201414774
cp ./bombs/bomb201414774/README ./allbombs/CS201401/U201414774
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414775 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414775
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414775
cd ../..
cp ./bombs/bomb201414775/bomb ./allbombs/CS201401/U201414775
cp ./bombs/bomb201414775/bomb.c ./allbombs/CS201401/U201414775
cp ./bombs/bomb201414775/ID ./allbombs/CS201401/U201414775
cp ./bombs/bomb201414775/README ./allbombs/CS201401/U201414775
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414776 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414776
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414776
cd ../..
cp ./bombs/bomb201414776/bomb ./allbombs/CS201401/U201414776
cp ./bombs/bomb201414776/bomb.c ./allbombs/CS201401/U201414776
cp ./bombs/bomb201414776/ID ./allbombs/CS201401/U201414776
cp ./bombs/bomb201414776/README ./allbombs/CS201401/U201414776
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414777 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414777
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414777
cd ../..
cp ./bombs/bomb201414777/bomb ./allbombs/CS201401/U201414777
cp ./bombs/bomb201414777/bomb.c ./allbombs/CS201401/U201414777
cp ./bombs/bomb201414777/ID ./allbombs/CS201401/U201414777
cp ./bombs/bomb201414777/README ./allbombs/CS201401/U201414777
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414778 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414778
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414778
cd ../..
cp ./bombs/bomb201414778/bomb ./allbombs/CS201401/U201414778
cp ./bombs/bomb201414778/bomb.c ./allbombs/CS201401/U201414778
cp ./bombs/bomb201414778/ID ./allbombs/CS201401/U201414778
cp ./bombs/bomb201414778/README ./allbombs/CS201401/U201414778
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414779 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414779
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414779
cd ../..
cp ./bombs/bomb201414779/bomb ./allbombs/CS201401/U201414779
cp ./bombs/bomb201414779/bomb.c ./allbombs/CS201401/U201414779
cp ./bombs/bomb201414779/ID ./allbombs/CS201401/U201414779
cp ./bombs/bomb201414779/README ./allbombs/CS201401/U201414779
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414780 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414780
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414780
cd ../..
cp ./bombs/bomb201414780/bomb ./allbombs/CS201401/U201414780
cp ./bombs/bomb201414780/bomb.c ./allbombs/CS201401/U201414780
cp ./bombs/bomb201414780/ID ./allbombs/CS201401/U201414780
cp ./bombs/bomb201414780/README ./allbombs/CS201401/U201414780
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414781 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414781
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414781
cd ../..
cp ./bombs/bomb201414781/bomb ./allbombs/CS201401/U201414781
cp ./bombs/bomb201414781/bomb.c ./allbombs/CS201401/U201414781
cp ./bombs/bomb201414781/ID ./allbombs/CS201401/U201414781
cp ./bombs/bomb201414781/README ./allbombs/CS201401/U201414781
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414782 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414782
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414782
cd ../..
cp ./bombs/bomb201414782/bomb ./allbombs/CS201401/U201414782
cp ./bombs/bomb201414782/bomb.c ./allbombs/CS201401/U201414782
cp ./bombs/bomb201414782/ID ./allbombs/CS201401/U201414782
cp ./bombs/bomb201414782/README ./allbombs/CS201401/U201414782
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414783 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414783
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414783
cd ../..
cp ./bombs/bomb201414783/bomb ./allbombs/CS201401/U201414783
cp ./bombs/bomb201414783/bomb.c ./allbombs/CS201401/U201414783
cp ./bombs/bomb201414783/ID ./allbombs/CS201401/U201414783
cp ./bombs/bomb201414783/README ./allbombs/CS201401/U201414783
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414784 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414784
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414784
cd ../..
cp ./bombs/bomb201414784/bomb ./allbombs/CS201401/U201414784
cp ./bombs/bomb201414784/bomb.c ./allbombs/CS201401/U201414784
cp ./bombs/bomb201414784/ID ./allbombs/CS201401/U201414784
cp ./bombs/bomb201414784/README ./allbombs/CS201401/U201414784
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414785 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414785
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414785
cd ../..
cp ./bombs/bomb201414785/bomb ./allbombs/CS201401/U201414785
cp ./bombs/bomb201414785/bomb.c ./allbombs/CS201401/U201414785
cp ./bombs/bomb201414785/ID ./allbombs/CS201401/U201414785
cp ./bombs/bomb201414785/README ./allbombs/CS201401/U201414785
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414786 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414786
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414786
cd ../..
cp ./bombs/bomb201414786/bomb ./allbombs/CS201401/U201414786
cp ./bombs/bomb201414786/bomb.c ./allbombs/CS201401/U201414786
cp ./bombs/bomb201414786/ID ./allbombs/CS201401/U201414786
cp ./bombs/bomb201414786/README ./allbombs/CS201401/U201414786
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414787 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414787
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414787
cd ../..
cp ./bombs/bomb201414787/bomb ./allbombs/CS201401/U201414787
cp ./bombs/bomb201414787/bomb.c ./allbombs/CS201401/U201414787
cp ./bombs/bomb201414787/ID ./allbombs/CS201401/U201414787
cp ./bombs/bomb201414787/README ./allbombs/CS201401/U201414787
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414788 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414788
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414788
cd ../..
cp ./bombs/bomb201414788/bomb ./allbombs/CS201401/U201414788
cp ./bombs/bomb201414788/bomb.c ./allbombs/CS201401/U201414788
cp ./bombs/bomb201414788/ID ./allbombs/CS201401/U201414788
cp ./bombs/bomb201414788/README ./allbombs/CS201401/U201414788
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414789 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414789
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414789
cd ../..
cp ./bombs/bomb201414789/bomb ./allbombs/CS201401/U201414789
cp ./bombs/bomb201414789/bomb.c ./allbombs/CS201401/U201414789
cp ./bombs/bomb201414789/ID ./allbombs/CS201401/U201414789
cp ./bombs/bomb201414789/README ./allbombs/CS201401/U201414789
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414790 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414790
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414790
cd ../..
cp ./bombs/bomb201414790/bomb ./allbombs/CS201401/U201414790
cp ./bombs/bomb201414790/bomb.c ./allbombs/CS201401/U201414790
cp ./bombs/bomb201414790/ID ./allbombs/CS201401/U201414790
cp ./bombs/bomb201414790/README ./allbombs/CS201401/U201414790
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414792 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414792
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414792
cd ../..
cp ./bombs/bomb201414792/bomb ./allbombs/CS201401/U201414792
cp ./bombs/bomb201414792/bomb.c ./allbombs/CS201401/U201414792
cp ./bombs/bomb201414792/ID ./allbombs/CS201401/U201414792
cp ./bombs/bomb201414792/README ./allbombs/CS201401/U201414792
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414793 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414793
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414793
cd ../..
cp ./bombs/bomb201414793/bomb ./allbombs/CS201401/U201414793
cp ./bombs/bomb201414793/bomb.c ./allbombs/CS201401/U201414793
cp ./bombs/bomb201414793/ID ./allbombs/CS201401/U201414793
cp ./bombs/bomb201414793/README ./allbombs/CS201401/U201414793
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414794 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414794
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414794
cd ../..
cp ./bombs/bomb201414794/bomb ./allbombs/CS201401/U201414794
cp ./bombs/bomb201414794/bomb.c ./allbombs/CS201401/U201414794
cp ./bombs/bomb201414794/ID ./allbombs/CS201401/U201414794
cp ./bombs/bomb201414794/README ./allbombs/CS201401/U201414794
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201313618 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201313618
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201313618
cd ../..
cp ./bombs/bomb201313618/bomb ./allbombs/CS201401/U201313618
cp ./bombs/bomb201313618/bomb.c ./allbombs/CS201401/U201313618
cp ./bombs/bomb201313618/ID ./allbombs/CS201401/U201313618
cp ./bombs/bomb201313618/README ./allbombs/CS201401/U201313618
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414795 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414795
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414795
cd ../..
cp ./bombs/bomb201414795/bomb ./allbombs/CS201401/U201414795
cp ./bombs/bomb201414795/bomb.c ./allbombs/CS201401/U201414795
cp ./bombs/bomb201414795/ID ./allbombs/CS201401/U201414795
cp ./bombs/bomb201414795/README ./allbombs/CS201401/U201414795
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414796 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414796
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414796
cd ../..
cp ./bombs/bomb201414796/bomb ./allbombs/CS201401/U201414796
cp ./bombs/bomb201414796/bomb.c ./allbombs/CS201401/U201414796
cp ./bombs/bomb201414796/ID ./allbombs/CS201401/U201414796
cp ./bombs/bomb201414796/README ./allbombs/CS201401/U201414796
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414797 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414797
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414797
cd ../..
cp ./bombs/bomb201414797/bomb ./allbombs/CS201401/U201414797
cp ./bombs/bomb201414797/bomb.c ./allbombs/CS201401/U201414797
cp ./bombs/bomb201414797/ID ./allbombs/CS201401/U201414797
cp ./bombs/bomb201414797/README ./allbombs/CS201401/U201414797
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414798 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414798
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414798
cd ../..
cp ./bombs/bomb201414798/bomb ./allbombs/CS201401/U201414798
cp ./bombs/bomb201414798/bomb.c ./allbombs/CS201401/U201414798
cp ./bombs/bomb201414798/ID ./allbombs/CS201401/U201414798
cp ./bombs/bomb201414798/README ./allbombs/CS201401/U201414798
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414800 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414800
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414800
cd ../..
cp ./bombs/bomb201414800/bomb ./allbombs/CS201401/U201414800
cp ./bombs/bomb201414800/bomb.c ./allbombs/CS201401/U201414800
cp ./bombs/bomb201414800/ID ./allbombs/CS201401/U201414800
cp ./bombs/bomb201414800/README ./allbombs/CS201401/U201414800
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414801 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414801
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414801
cd ../..
cp ./bombs/bomb201414801/bomb ./allbombs/CS201401/U201414801
cp ./bombs/bomb201414801/bomb.c ./allbombs/CS201401/U201414801
cp ./bombs/bomb201414801/ID ./allbombs/CS201401/U201414801
cp ./bombs/bomb201414801/README ./allbombs/CS201401/U201414801
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414802 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414802
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414802
cd ../..
cp ./bombs/bomb201414802/bomb ./allbombs/CS201401/U201414802
cp ./bombs/bomb201414802/bomb.c ./allbombs/CS201401/U201414802
cp ./bombs/bomb201414802/ID ./allbombs/CS201401/U201414802
cp ./bombs/bomb201414802/README ./allbombs/CS201401/U201414802
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414803 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414803
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414803
cd ../..
cp ./bombs/bomb201414803/bomb ./allbombs/CS201401/U201414803
cp ./bombs/bomb201414803/bomb.c ./allbombs/CS201401/U201414803
cp ./bombs/bomb201414803/ID ./allbombs/CS201401/U201414803
cp ./bombs/bomb201414803/README ./allbombs/CS201401/U201414803
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414804 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414804
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414804
cd ../..
cp ./bombs/bomb201414804/bomb ./allbombs/CS201401/U201414804
cp ./bombs/bomb201414804/bomb.c ./allbombs/CS201401/U201414804
cp ./bombs/bomb201414804/ID ./allbombs/CS201401/U201414804
cp ./bombs/bomb201414804/README ./allbombs/CS201401/U201414804
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414805 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414805
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414805
cd ../..
cp ./bombs/bomb201414805/bomb ./allbombs/CS201401/U201414805
cp ./bombs/bomb201414805/bomb.c ./allbombs/CS201401/U201414805
cp ./bombs/bomb201414805/ID ./allbombs/CS201401/U201414805
cp ./bombs/bomb201414805/README ./allbombs/CS201401/U201414805
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414806 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414806
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414806
cd ../..
cp ./bombs/bomb201414806/bomb ./allbombs/CS201401/U201414806
cp ./bombs/bomb201414806/bomb.c ./allbombs/CS201401/U201414806
cp ./bombs/bomb201414806/ID ./allbombs/CS201401/U201414806
cp ./bombs/bomb201414806/README ./allbombs/CS201401/U201414806
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414808 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414808
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414808
cd ../..
cp ./bombs/bomb201414808/bomb ./allbombs/CS201401/U201414808
cp ./bombs/bomb201414808/bomb.c ./allbombs/CS201401/U201414808
cp ./bombs/bomb201414808/ID ./allbombs/CS201401/U201414808
cp ./bombs/bomb201414808/README ./allbombs/CS201401/U201414808
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414809 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414809
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414809
cd ../..
cp ./bombs/bomb201414809/bomb ./allbombs/CS201401/U201414809
cp ./bombs/bomb201414809/bomb.c ./allbombs/CS201401/U201414809
cp ./bombs/bomb201414809/ID ./allbombs/CS201401/U201414809
cp ./bombs/bomb201414809/README ./allbombs/CS201401/U201414809
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414810 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414810
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414810
cd ../..
cp ./bombs/bomb201414810/bomb ./allbombs/CS201401/U201414810
cp ./bombs/bomb201414810/bomb.c ./allbombs/CS201401/U201414810
cp ./bombs/bomb201414810/ID ./allbombs/CS201401/U201414810
cp ./bombs/bomb201414810/README ./allbombs/CS201401/U201414810
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414812 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414812
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414812
cd ../..
cp ./bombs/bomb201414812/bomb ./allbombs/CS201401/U201414812
cp ./bombs/bomb201414812/bomb.c ./allbombs/CS201401/U201414812
cp ./bombs/bomb201414812/ID ./allbombs/CS201401/U201414812
cp ./bombs/bomb201414812/README ./allbombs/CS201401/U201414812
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414813 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414813
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414813
cd ../..
cp ./bombs/bomb201414813/bomb ./allbombs/CS201401/U201414813
cp ./bombs/bomb201414813/bomb.c ./allbombs/CS201401/U201414813
cp ./bombs/bomb201414813/ID ./allbombs/CS201401/U201414813
cp ./bombs/bomb201414813/README ./allbombs/CS201401/U201414813
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414814 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414814
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414814
cd ../..
cp ./bombs/bomb201414814/bomb ./allbombs/CS201401/U201414814
cp ./bombs/bomb201414814/bomb.c ./allbombs/CS201401/U201414814
cp ./bombs/bomb201414814/ID ./allbombs/CS201401/U201414814
cp ./bombs/bomb201414814/README ./allbombs/CS201401/U201414814
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414815 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414815
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414815
cd ../..
cp ./bombs/bomb201414815/bomb ./allbombs/CS201401/U201414815
cp ./bombs/bomb201414815/bomb.c ./allbombs/CS201401/U201414815
cp ./bombs/bomb201414815/ID ./allbombs/CS201401/U201414815
cp ./bombs/bomb201414815/README ./allbombs/CS201401/U201414815
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414816 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414816
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414816
cd ../..
cp ./bombs/bomb201414816/bomb ./allbombs/CS201401/U201414816
cp ./bombs/bomb201414816/bomb.c ./allbombs/CS201401/U201414816
cp ./bombs/bomb201414816/ID ./allbombs/CS201401/U201414816
cp ./bombs/bomb201414816/README ./allbombs/CS201401/U201414816
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414817 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414817
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414817
cd ../..
cp ./bombs/bomb201414817/bomb ./allbombs/CS201401/U201414817
cp ./bombs/bomb201414817/bomb.c ./allbombs/CS201401/U201414817
cp ./bombs/bomb201414817/ID ./allbombs/CS201401/U201414817
cp ./bombs/bomb201414817/README ./allbombs/CS201401/U201414817
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414818 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414818
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414818
cd ../..
cp ./bombs/bomb201414818/bomb ./allbombs/CS201401/U201414818
cp ./bombs/bomb201414818/bomb.c ./allbombs/CS201401/U201414818
cp ./bombs/bomb201414818/ID ./allbombs/CS201401/U201414818
cp ./bombs/bomb201414818/README ./allbombs/CS201401/U201414818
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414819 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414819
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414819
cd ../..
cp ./bombs/bomb201414819/bomb ./allbombs/CS201401/U201414819
cp ./bombs/bomb201414819/bomb.c ./allbombs/CS201401/U201414819
cp ./bombs/bomb201414819/ID ./allbombs/CS201401/U201414819
cp ./bombs/bomb201414819/README ./allbombs/CS201401/U201414819
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414820 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414820
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414820
cd ../..
cp ./bombs/bomb201414820/bomb ./allbombs/CS201401/U201414820
cp ./bombs/bomb201414820/bomb.c ./allbombs/CS201401/U201414820
cp ./bombs/bomb201414820/ID ./allbombs/CS201401/U201414820
cp ./bombs/bomb201414820/README ./allbombs/CS201401/U201414820
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414821 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414821
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414821
cd ../..
cp ./bombs/bomb201414821/bomb ./allbombs/CS201401/U201414821
cp ./bombs/bomb201414821/bomb.c ./allbombs/CS201401/U201414821
cp ./bombs/bomb201414821/ID ./allbombs/CS201401/U201414821
cp ./bombs/bomb201414821/README ./allbombs/CS201401/U201414821
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414822 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414822
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414822
cd ../..
cp ./bombs/bomb201414822/bomb ./allbombs/CS201401/U201414822
cp ./bombs/bomb201414822/bomb.c ./allbombs/CS201401/U201414822
cp ./bombs/bomb201414822/ID ./allbombs/CS201401/U201414822
cp ./bombs/bomb201414822/README ./allbombs/CS201401/U201414822
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414823 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414823
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414823
cd ../..
cp ./bombs/bomb201414823/bomb ./allbombs/CS201401/U201414823
cp ./bombs/bomb201414823/bomb.c ./allbombs/CS201401/U201414823
cp ./bombs/bomb201414823/ID ./allbombs/CS201401/U201414823
cp ./bombs/bomb201414823/README ./allbombs/CS201401/U201414823
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414825 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414825
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414825
cd ../..
cp ./bombs/bomb201414825/bomb ./allbombs/CS201401/U201414825
cp ./bombs/bomb201414825/bomb.c ./allbombs/CS201401/U201414825
cp ./bombs/bomb201414825/ID ./allbombs/CS201401/U201414825
cp ./bombs/bomb201414825/README ./allbombs/CS201401/U201414825
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414826 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414826
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414826
cd ../..
cp ./bombs/bomb201414826/bomb ./allbombs/CS201401/U201414826
cp ./bombs/bomb201414826/bomb.c ./allbombs/CS201401/U201414826
cp ./bombs/bomb201414826/ID ./allbombs/CS201401/U201414826
cp ./bombs/bomb201414826/README ./allbombs/CS201401/U201414826
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414827 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414827
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414827
cd ../..
cp ./bombs/bomb201414827/bomb ./allbombs/CS201401/U201414827
cp ./bombs/bomb201414827/bomb.c ./allbombs/CS201401/U201414827
cp ./bombs/bomb201414827/ID ./allbombs/CS201401/U201414827
cp ./bombs/bomb201414827/README ./allbombs/CS201401/U201414827
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414828 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414828
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414828
cd ../..
cp ./bombs/bomb201414828/bomb ./allbombs/CS201401/U201414828
cp ./bombs/bomb201414828/bomb.c ./allbombs/CS201401/U201414828
cp ./bombs/bomb201414828/ID ./allbombs/CS201401/U201414828
cp ./bombs/bomb201414828/README ./allbombs/CS201401/U201414828
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414829 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414829
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414829
cd ../..
cp ./bombs/bomb201414829/bomb ./allbombs/CS201401/U201414829
cp ./bombs/bomb201414829/bomb.c ./allbombs/CS201401/U201414829
cp ./bombs/bomb201414829/ID ./allbombs/CS201401/U201414829
cp ./bombs/bomb201414829/README ./allbombs/CS201401/U201414829
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414830 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414830
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414830
cd ../..
cp ./bombs/bomb201414830/bomb ./allbombs/CS201401/U201414830
cp ./bombs/bomb201414830/bomb.c ./allbombs/CS201401/U201414830
cp ./bombs/bomb201414830/ID ./allbombs/CS201401/U201414830
cp ./bombs/bomb201414830/README ./allbombs/CS201401/U201414830
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414831 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414831
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414831
cd ../..
cp ./bombs/bomb201414831/bomb ./allbombs/CS201401/U201414831
cp ./bombs/bomb201414831/bomb.c ./allbombs/CS201401/U201414831
cp ./bombs/bomb201414831/ID ./allbombs/CS201401/U201414831
cp ./bombs/bomb201414831/README ./allbombs/CS201401/U201414831
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414832 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414832
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414832
cd ../..
cp ./bombs/bomb201414832/bomb ./allbombs/CS201401/U201414832
cp ./bombs/bomb201414832/bomb.c ./allbombs/CS201401/U201414832
cp ./bombs/bomb201414832/ID ./allbombs/CS201401/U201414832
cp ./bombs/bomb201414832/README ./allbombs/CS201401/U201414832
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414833 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414833
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414833
cd ../..
cp ./bombs/bomb201414833/bomb ./allbombs/CS201401/U201414833
cp ./bombs/bomb201414833/bomb.c ./allbombs/CS201401/U201414833
cp ./bombs/bomb201414833/ID ./allbombs/CS201401/U201414833
cp ./bombs/bomb201414833/README ./allbombs/CS201401/U201414833
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414834 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414834
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414834
cd ../..
cp ./bombs/bomb201414834/bomb ./allbombs/CS201401/U201414834
cp ./bombs/bomb201414834/bomb.c ./allbombs/CS201401/U201414834
cp ./bombs/bomb201414834/ID ./allbombs/CS201401/U201414834
cp ./bombs/bomb201414834/README ./allbombs/CS201401/U201414834
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414835 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414835
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414835
cd ../..
cp ./bombs/bomb201414835/bomb ./allbombs/CS201401/U201414835
cp ./bombs/bomb201414835/bomb.c ./allbombs/CS201401/U201414835
cp ./bombs/bomb201414835/ID ./allbombs/CS201401/U201414835
cp ./bombs/bomb201414835/README ./allbombs/CS201401/U201414835
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414836 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414836
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414836
cd ../..
cp ./bombs/bomb201414836/bomb ./allbombs/CS201401/U201414836
cp ./bombs/bomb201414836/bomb.c ./allbombs/CS201401/U201414836
cp ./bombs/bomb201414836/ID ./allbombs/CS201401/U201414836
cp ./bombs/bomb201414836/README ./allbombs/CS201401/U201414836
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414837 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414837
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414837
cd ../..
cp ./bombs/bomb201414837/bomb ./allbombs/CS201401/U201414837
cp ./bombs/bomb201414837/bomb.c ./allbombs/CS201401/U201414837
cp ./bombs/bomb201414837/ID ./allbombs/CS201401/U201414837
cp ./bombs/bomb201414837/README ./allbombs/CS201401/U201414837
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414838 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414838
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414838
cd ../..
cp ./bombs/bomb201414838/bomb ./allbombs/CS201401/U201414838
cp ./bombs/bomb201414838/bomb.c ./allbombs/CS201401/U201414838
cp ./bombs/bomb201414838/ID ./allbombs/CS201401/U201414838
cp ./bombs/bomb201414838/README ./allbombs/CS201401/U201414838
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414839 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414839
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414839
cd ../..
cp ./bombs/bomb201414839/bomb ./allbombs/CS201401/U201414839
cp ./bombs/bomb201414839/bomb.c ./allbombs/CS201401/U201414839
cp ./bombs/bomb201414839/ID ./allbombs/CS201401/U201414839
cp ./bombs/bomb201414839/README ./allbombs/CS201401/U201414839
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414840 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414840
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414840
cd ../..
cp ./bombs/bomb201414840/bomb ./allbombs/CS201401/U201414840
cp ./bombs/bomb201414840/bomb.c ./allbombs/CS201401/U201414840
cp ./bombs/bomb201414840/ID ./allbombs/CS201401/U201414840
cp ./bombs/bomb201414840/README ./allbombs/CS201401/U201414840
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414841 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414841
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414841
cd ../..
cp ./bombs/bomb201414841/bomb ./allbombs/CS201401/U201414841
cp ./bombs/bomb201414841/bomb.c ./allbombs/CS201401/U201414841
cp ./bombs/bomb201414841/ID ./allbombs/CS201401/U201414841
cp ./bombs/bomb201414841/README ./allbombs/CS201401/U201414841
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414842 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414842
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414842
cd ../..
cp ./bombs/bomb201414842/bomb ./allbombs/CS201401/U201414842
cp ./bombs/bomb201414842/bomb.c ./allbombs/CS201401/U201414842
cp ./bombs/bomb201414842/ID ./allbombs/CS201401/U201414842
cp ./bombs/bomb201414842/README ./allbombs/CS201401/U201414842
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414843 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414843
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414843
cd ../..
cp ./bombs/bomb201414843/bomb ./allbombs/CS201401/U201414843
cp ./bombs/bomb201414843/bomb.c ./allbombs/CS201401/U201414843
cp ./bombs/bomb201414843/ID ./allbombs/CS201401/U201414843
cp ./bombs/bomb201414843/README ./allbombs/CS201401/U201414843
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414844 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414844
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414844
cd ../..
cp ./bombs/bomb201414844/bomb ./allbombs/CS201401/U201414844
cp ./bombs/bomb201414844/bomb.c ./allbombs/CS201401/U201414844
cp ./bombs/bomb201414844/ID ./allbombs/CS201401/U201414844
cp ./bombs/bomb201414844/README ./allbombs/CS201401/U201414844
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414845 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414845
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414845
cd ../..
cp ./bombs/bomb201414845/bomb ./allbombs/CS201401/U201414845
cp ./bombs/bomb201414845/bomb.c ./allbombs/CS201401/U201414845
cp ./bombs/bomb201414845/ID ./allbombs/CS201401/U201414845
cp ./bombs/bomb201414845/README ./allbombs/CS201401/U201414845
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414846 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414846
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414846
cd ../..
cp ./bombs/bomb201414846/bomb ./allbombs/CS201401/U201414846
cp ./bombs/bomb201414846/bomb.c ./allbombs/CS201401/U201414846
cp ./bombs/bomb201414846/ID ./allbombs/CS201401/U201414846
cp ./bombs/bomb201414846/README ./allbombs/CS201401/U201414846
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414847 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414847
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414847
cd ../..
cp ./bombs/bomb201414847/bomb ./allbombs/CS201401/U201414847
cp ./bombs/bomb201414847/bomb.c ./allbombs/CS201401/U201414847
cp ./bombs/bomb201414847/ID ./allbombs/CS201401/U201414847
cp ./bombs/bomb201414847/README ./allbombs/CS201401/U201414847
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414848 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414848
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414848
cd ../..
cp ./bombs/bomb201414848/bomb ./allbombs/CS201401/U201414848
cp ./bombs/bomb201414848/bomb.c ./allbombs/CS201401/U201414848
cp ./bombs/bomb201414848/ID ./allbombs/CS201401/U201414848
cp ./bombs/bomb201414848/README ./allbombs/CS201401/U201414848
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414850 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414850
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414850
cd ../..
cp ./bombs/bomb201414850/bomb ./allbombs/CS201401/U201414850
cp ./bombs/bomb201414850/bomb.c ./allbombs/CS201401/U201414850
cp ./bombs/bomb201414850/ID ./allbombs/CS201401/U201414850
cp ./bombs/bomb201414850/README ./allbombs/CS201401/U201414850
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414851 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414851
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414851
cd ../..
cp ./bombs/bomb201414851/bomb ./allbombs/CS201401/U201414851
cp ./bombs/bomb201414851/bomb.c ./allbombs/CS201401/U201414851
cp ./bombs/bomb201414851/ID ./allbombs/CS201401/U201414851
cp ./bombs/bomb201414851/README ./allbombs/CS201401/U201414851
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414707 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414707
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414707
cd ../..
cp ./bombs/bomb201414707/bomb ./allbombs/CS201401/U201414707
cp ./bombs/bomb201414707/bomb.c ./allbombs/CS201401/U201414707
cp ./bombs/bomb201414707/ID ./allbombs/CS201401/U201414707
cp ./bombs/bomb201414707/README ./allbombs/CS201401/U201414707
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414708 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414708
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414708
cd ../..
cp ./bombs/bomb201414708/bomb ./allbombs/CS201401/U201414708
cp ./bombs/bomb201414708/bomb.c ./allbombs/CS201401/U201414708
cp ./bombs/bomb201414708/ID ./allbombs/CS201401/U201414708
cp ./bombs/bomb201414708/README ./allbombs/CS201401/U201414708
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414709 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414709
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414709
cd ../..
cp ./bombs/bomb201414709/bomb ./allbombs/CS201401/U201414709
cp ./bombs/bomb201414709/bomb.c ./allbombs/CS201401/U201414709
cp ./bombs/bomb201414709/ID ./allbombs/CS201401/U201414709
cp ./bombs/bomb201414709/README ./allbombs/CS201401/U201414709
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414711 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414711
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414711
cd ../..
cp ./bombs/bomb201414711/bomb ./allbombs/CS201401/U201414711
cp ./bombs/bomb201414711/bomb.c ./allbombs/CS201401/U201414711
cp ./bombs/bomb201414711/ID ./allbombs/CS201401/U201414711
cp ./bombs/bomb201414711/README ./allbombs/CS201401/U201414711
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414712 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414712
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414712
cd ../..
cp ./bombs/bomb201414712/bomb ./allbombs/CS201401/U201414712
cp ./bombs/bomb201414712/bomb.c ./allbombs/CS201401/U201414712
cp ./bombs/bomb201414712/ID ./allbombs/CS201401/U201414712
cp ./bombs/bomb201414712/README ./allbombs/CS201401/U201414712
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414713 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414713
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414713
cd ../..
cp ./bombs/bomb201414713/bomb ./allbombs/CS201401/U201414713
cp ./bombs/bomb201414713/bomb.c ./allbombs/CS201401/U201414713
cp ./bombs/bomb201414713/ID ./allbombs/CS201401/U201414713
cp ./bombs/bomb201414713/README ./allbombs/CS201401/U201414713
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414714 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414714
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414714
cd ../..
cp ./bombs/bomb201414714/bomb ./allbombs/CS201401/U201414714
cp ./bombs/bomb201414714/bomb.c ./allbombs/CS201401/U201414714
cp ./bombs/bomb201414714/ID ./allbombs/CS201401/U201414714
cp ./bombs/bomb201414714/README ./allbombs/CS201401/U201414714
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414715 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414715
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414715
cd ../..
cp ./bombs/bomb201414715/bomb ./allbombs/CS201401/U201414715
cp ./bombs/bomb201414715/bomb.c ./allbombs/CS201401/U201414715
cp ./bombs/bomb201414715/ID ./allbombs/CS201401/U201414715
cp ./bombs/bomb201414715/README ./allbombs/CS201401/U201414715
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414717 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414717
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414717
cd ../..
cp ./bombs/bomb201414717/bomb ./allbombs/CS201401/U201414717
cp ./bombs/bomb201414717/bomb.c ./allbombs/CS201401/U201414717
cp ./bombs/bomb201414717/ID ./allbombs/CS201401/U201414717
cp ./bombs/bomb201414717/README ./allbombs/CS201401/U201414717
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414718 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414718
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414718
cd ../..
cp ./bombs/bomb201414718/bomb ./allbombs/CS201401/U201414718
cp ./bombs/bomb201414718/bomb.c ./allbombs/CS201401/U201414718
cp ./bombs/bomb201414718/ID ./allbombs/CS201401/U201414718
cp ./bombs/bomb201414718/README ./allbombs/CS201401/U201414718
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414719 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414719
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414719
cd ../..
cp ./bombs/bomb201414719/bomb ./allbombs/CS201401/U201414719
cp ./bombs/bomb201414719/bomb.c ./allbombs/CS201401/U201414719
cp ./bombs/bomb201414719/ID ./allbombs/CS201401/U201414719
cp ./bombs/bomb201414719/README ./allbombs/CS201401/U201414719
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414720 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414720
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414720
cd ../..
cp ./bombs/bomb201414720/bomb ./allbombs/CS201401/U201414720
cp ./bombs/bomb201414720/bomb.c ./allbombs/CS201401/U201414720
cp ./bombs/bomb201414720/ID ./allbombs/CS201401/U201414720
cp ./bombs/bomb201414720/README ./allbombs/CS201401/U201414720
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414721 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414721
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414721
cd ../..
cp ./bombs/bomb201414721/bomb ./allbombs/CS201401/U201414721
cp ./bombs/bomb201414721/bomb.c ./allbombs/CS201401/U201414721
cp ./bombs/bomb201414721/ID ./allbombs/CS201401/U201414721
cp ./bombs/bomb201414721/README ./allbombs/CS201401/U201414721
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414722 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414722
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414722
cd ../..
cp ./bombs/bomb201414722/bomb ./allbombs/CS201401/U201414722
cp ./bombs/bomb201414722/bomb.c ./allbombs/CS201401/U201414722
cp ./bombs/bomb201414722/ID ./allbombs/CS201401/U201414722
cp ./bombs/bomb201414722/README ./allbombs/CS201401/U201414722
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414723 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414723
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414723
cd ../..
cp ./bombs/bomb201414723/bomb ./allbombs/CS201401/U201414723
cp ./bombs/bomb201414723/bomb.c ./allbombs/CS201401/U201414723
cp ./bombs/bomb201414723/ID ./allbombs/CS201401/U201414723
cp ./bombs/bomb201414723/README ./allbombs/CS201401/U201414723
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414725 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414725
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414725
cd ../..
cp ./bombs/bomb201414725/bomb ./allbombs/CS201401/U201414725
cp ./bombs/bomb201414725/bomb.c ./allbombs/CS201401/U201414725
cp ./bombs/bomb201414725/ID ./allbombs/CS201401/U201414725
cp ./bombs/bomb201414725/README ./allbombs/CS201401/U201414725
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414726 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414726
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414726
cd ../..
cp ./bombs/bomb201414726/bomb ./allbombs/CS201401/U201414726
cp ./bombs/bomb201414726/bomb.c ./allbombs/CS201401/U201414726
cp ./bombs/bomb201414726/ID ./allbombs/CS201401/U201414726
cp ./bombs/bomb201414726/README ./allbombs/CS201401/U201414726
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414727 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414727
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414727
cd ../..
cp ./bombs/bomb201414727/bomb ./allbombs/CS201401/U201414727
cp ./bombs/bomb201414727/bomb.c ./allbombs/CS201401/U201414727
cp ./bombs/bomb201414727/ID ./allbombs/CS201401/U201414727
cp ./bombs/bomb201414727/README ./allbombs/CS201401/U201414727
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414728 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414728
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414728
cd ../..
cp ./bombs/bomb201414728/bomb ./allbombs/CS201401/U201414728
cp ./bombs/bomb201414728/bomb.c ./allbombs/CS201401/U201414728
cp ./bombs/bomb201414728/ID ./allbombs/CS201401/U201414728
cp ./bombs/bomb201414728/README ./allbombs/CS201401/U201414728
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414729 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414729
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414729
cd ../..
cp ./bombs/bomb201414729/bomb ./allbombs/CS201401/U201414729
cp ./bombs/bomb201414729/bomb.c ./allbombs/CS201401/U201414729
cp ./bombs/bomb201414729/ID ./allbombs/CS201401/U201414729
cp ./bombs/bomb201414729/README ./allbombs/CS201401/U201414729
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414730 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414730
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414730
cd ../..
cp ./bombs/bomb201414730/bomb ./allbombs/CS201401/U201414730
cp ./bombs/bomb201414730/bomb.c ./allbombs/CS201401/U201414730
cp ./bombs/bomb201414730/ID ./allbombs/CS201401/U201414730
cp ./bombs/bomb201414730/README ./allbombs/CS201401/U201414730
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414731 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414731
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414731
cd ../..
cp ./bombs/bomb201414731/bomb ./allbombs/CS201401/U201414731
cp ./bombs/bomb201414731/bomb.c ./allbombs/CS201401/U201414731
cp ./bombs/bomb201414731/ID ./allbombs/CS201401/U201414731
cp ./bombs/bomb201414731/README ./allbombs/CS201401/U201414731
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414732 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414732
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414732
cd ../..
cp ./bombs/bomb201414732/bomb ./allbombs/CS201401/U201414732
cp ./bombs/bomb201414732/bomb.c ./allbombs/CS201401/U201414732
cp ./bombs/bomb201414732/ID ./allbombs/CS201401/U201414732
cp ./bombs/bomb201414732/README ./allbombs/CS201401/U201414732
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414733 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414733
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414733
cd ../..
cp ./bombs/bomb201414733/bomb ./allbombs/CS201401/U201414733
cp ./bombs/bomb201414733/bomb.c ./allbombs/CS201401/U201414733
cp ./bombs/bomb201414733/ID ./allbombs/CS201401/U201414733
cp ./bombs/bomb201414733/README ./allbombs/CS201401/U201414733
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414734 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414734
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414734
cd ../..
cp ./bombs/bomb201414734/bomb ./allbombs/CS201401/U201414734
cp ./bombs/bomb201414734/bomb.c ./allbombs/CS201401/U201414734
cp ./bombs/bomb201414734/ID ./allbombs/CS201401/U201414734
cp ./bombs/bomb201414734/README ./allbombs/CS201401/U201414734
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414735 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414735
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414735
cd ../..
cp ./bombs/bomb201414735/bomb ./allbombs/CS201401/U201414735
cp ./bombs/bomb201414735/bomb.c ./allbombs/CS201401/U201414735
cp ./bombs/bomb201414735/ID ./allbombs/CS201401/U201414735
cp ./bombs/bomb201414735/README ./allbombs/CS201401/U201414735
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201417773 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201417773
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201417773
cd ../..
cp ./bombs/bomb201417773/bomb ./allbombs/CS201401/U201417773
cp ./bombs/bomb201417773/bomb.c ./allbombs/CS201401/U201417773
cp ./bombs/bomb201417773/ID ./allbombs/CS201401/U201417773
cp ./bombs/bomb201417773/README ./allbombs/CS201401/U201417773
cd allbombs
zip -r CS201401.zip CS201401
cd ..

./makebomb.pl -i 201414710 -s ./src -b ./bombs -l bomblab -u dqwang@hust.edu.cn -v 201414710
cd allbombs
mkdir CS201401
cd CS201401
mkdir U201414710
cd ../..
cp ./bombs/bomb201414710/bomb ./allbombs/CS201401/U201414710
cp ./bombs/bomb201414710/bomb.c ./allbombs/CS201401/U201414710
cp ./bombs/bomb201414710/ID ./allbombs/CS201401/U201414710
cp ./bombs/bomb201414710/README ./allbombs/CS201401/U201414710
cd allbombs
zip -r CS201401.zip CS201401
cd ..

